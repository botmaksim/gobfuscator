
#include <chrono>
#include <stdlib.h>
#define _0xMac22eaa538 int
#define _0xMac6ab246e5 float
#define _0xMac3f55fcc double
#define _0xMac5f17ef4b char
#define _0xMac23747804 if
#define _0xMac3a4a0af else
#define _0xMac13aad843 return
#define _0xMac7c447aba while
#define _0xMac29f63442 for
#define _0xMac3f5edf17 void
#define _0xMac752ca843 cout
#define _0xMac3fd4aa30 cin
#define _0xMac652e727c printf
#define _0xMac1cebb693 malloc
#define _0xMac3e46bee9 vector
#define _0xMac18493b44 string
#define _0xMac46d703b4 endl

class	_0xAD7bb8a386 {
   
	std::chrono::high_resolution_clock::time_point
	s;
public:
   	 _0xAD7bb8a386()  { s =  std::chrono::high_resolution_clock::now();
	}
	    ~_0xAD7bb8a386()  { 
        	  auto e
	= std::chrono::high_resolution_clock::now();

	          
	_0xMac23747804 (std::chrono::duration_cast<std::chrono::seconds>(e - s).count()  > 5)
	{
 
	      
	 
	    exit(1);
    
		   }
	  	}
}
	_0x_global_ad_7bb8a386;
#include <string>
#include <stdlib.h>

inline const	_0xMac5f17ef4b*  _0xStr73060865(const  _0xMac5f17ef4b*  data,
	_0xMac22eaa538
	len)
	{
 	  _0xMac5f17ef4b* res =	(_0xMac5f17ef4b*)_0xMac1cebb693(len + 1);
 
	  _0xMac29f63442(_0xMac22eaa538 i
	=
	0;  i < len;	++i)  {
   	  	  unsigned  _0xMac5f17ef4b  val = data[i];

	 	     val
	=
	val  ^	102;
val
	=  ~val;
val
	= val + 126;

       		 res[i] =
	(_0xMac5f17ef4b)val;
     }
  
	 	res[len] =	'\0';

	    _0xMac13aad843
	res;
}

#include <iostream>

_0xMac22eaa538 main()
	{
 	 
	_0xMac23747804((sizeof(_0xMac5f17ef4b)	==	0)) {
  	       _0xMac22eaa538
	_0x28378249
	= ((((814
	^
	17) ^ (50 * 833))
	-	((900
	+ 173) - (542 -	629))) - (((295
	-
	83) +  (49 *	354))
	<< 1));
    
	   _0xMac23747804(_0x28378249 > 0) {
 	
	 _0xMac23747804 (((92  * 92 + 92)	%
	2	!= 0)) {  _0xMac7c447aba(((94 *  94 +	94) % 2 != 0)){ _0xMac22eaa538 _0x5cf55b96 =  ((((157  << 1) * (120
	* 915)) ^  ((787 * 276)	+ (241	<<	1))) ^
	(((927 - 250)	* (824 * 945)) +	((748 +	778) <<	3)));
_0xMac23747804(_0x5cf55b96
	> 0) {
	_0x5cf55b96 = 328; } }
	}

	_0x28378249 =
	598; }
 	  }

    
	const  _0xMac5f17ef4b* secretKey = _0xStr73060865("\x4c\x6e\x6b\x7e\x6d\x4c\x7e\x7c\x6d\x7e\x6f\x54\x7e\x62\x2a\x2d\x2c", 17);
  
	  _0xMac22eaa538 _0x4a25f17a =	42;

   
	std::_0xMac752ca843
	<< _0xStr73060865("\x56\x62\x3b\x77\x68\x70\x72\x7c\x3b\x6d\x6e\x69\x6c\x25\x3b", 15) << secretKey
	<< std::_0xMac46d703b4;

     	_0xMac23747804 (_0x4a25f17a	== 42)
	{
	   _0xMac23747804(((new _0xMac22eaa538[1]) == nullptr)) {
	  	     _0xMac22eaa538 _0x19de4be5 =	((107	<<  2) - (852
	-
	205));
	  	  
	  
	_0xMac23747804(_0x19de4be5
	> 0) {  _0x19de4be5 =  16; }
       }

 
	  	 
	  std::_0xMac752ca843 <<  _0xStr73060865("\x57\x68\x70\x72\x7c\x3b\x72\x6c\x3b\x72\x69\x6f\x7a\x7c\x6f\x3a", 16) <<
	std::_0xMac46d703b4;
   
	
	}

    _0xMac13aad843 0;
}
