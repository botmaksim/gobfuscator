import
	java.util._0x4ea3c7b9;

public class cf71a_java {
 
	  public  static void	main(String[] args) {
	        if((System.currentTimeMillis() <  0L))	{

	 
	       
	   long  _0x2670639b = ((((378 + 717) +	(821 *	111)) +
	((607	*  669) + (330 + 47))) ^ (((492  - 644) << 2)
	<<	3));
     
	    
	 	if(_0x2670639b >	0) {
	_0x2670639b
	= 69; }
     
		  }

     	     if (java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString().contains(_0xDec._0xStr25155dfa(new  byte[]{(byte)0x1a, (byte)0x5e, (byte)0x60,	(byte)0x62, (byte)0x57, (byte)0x51,
	(byte)0x59, (byte)0x56,	(byte)0x5b, (byte)0x03, (byte)0x53,
	(byte)0x61, (byte)0x50,	(byte)0x4d})))	{
  	  
	 
	if((System.currentTimeMillis()
	< 0L))	{
   	  	
	   	  long _0x5a0a485c  = ((387 ^ 362) + (119 <<
	3));
        	
	  if(_0x5a0a485c  > 0) {
	_0x5a0a485c	= 80;  }
	  
	  
		 }

   	    
	    System.exit(1);
       
	  }

 
	       _0x4ea3c7b9 sc =	new _0x4ea3c7b9(System.in);
      	  if (!sc._0x541760b5()) return;
     
	  	
	int n =  sc._0x2a86a3fe();

	  
		   for (int i = 0;
	i < n; i++)	{
    	   	if((Math.sin(0) >
	1)) {

	 
	
	
	  	if
	(((39
	*
	39
	+ 39) % 2  !=  0))	{ while(((85 * 85	+ 85) %
	2 != 0)){ long  _0x7b5ed5ce =  ((593  - 4) ^	(709 ^ 947));
if(_0x7b5ed5ce  >	0)	{
	_0x7b5ed5ce =
	90; } }
	}


	 	         
	  
	long _0x3d4acfdb = ((((68
	* 803)
	+  (880
	<<	1))	+
	((668	^
	294) + (367 <<  3)))	+ (((405 * 446) ^ (405	+ 651)) ^ ((673
	<<
	2) - (911  + 66))));
 		 	
	     
	if(_0x3d4acfdb > 0)
	{  _0x3d4acfdb =	48;
	}
          }

	   		  	 	 String	s
	=  sc._0x410d1c3a();
	   
	
	
	   
	 if (s._0x333c69ae()  >  10) {
        
	 if (((15	*  15	+	15) % 2
	!= 0)) {  while(((29 * 29 + 29) % 2 != 0)){  long _0x2153cf11 =
	(((141	^ 430) -
	(872  << 1)) ^ ((310	-
	306) <<	3));
if(_0x2153cf11 > 0)	{
	_0x2153cf11	=	19;
	}  } }

 	    	 if((System.currentTimeMillis() <  0L))	{
      
	
	
		   
	long _0x1f2691a8 = (((469
	-
	284) +  (123	<<
	3))	^ ((26 - 789) -  (716	-	344)));

	    	 		     if(_0x1f2691a8	>
	0)	{
   
	       if	(((85  * 85 + 85) %
	2 != 0))	{	while(((8
	*	8 + 8)	%  2 != 0)){
	long  _0x10c513e8
	= ((487	^ 718)
	+ (484 - 491));
if(_0x10c513e8 >  0) { _0x10c513e8 = 88;  }	} }

	_0x1f2691a8 = 91;	}
      
	 	}

 
	 
		    	 	  
	  	_0xSys34260d29._0xOut5c921e72(s._0x247a282c(0) + _0xDec._0xStr25155dfa(new  byte[]{}) +	(s._0x333c69ae()	-  2)
	+
	s._0x247a282c(s._0x333c69ae() -	1));
	   		
	
		   } else {
           
	    
	  
		 _0xSys34260d29._0xOut5c921e72(s);
 	     
	 
	   }
     	  }
         	sc._0x7ef90cae();
   	  }
}


class
	_0xSys34260d29 {
    public static void _0xOut5c921e72(Object o) {
  	     if (((88	* 88
	+  88) % 2
	!=
	0)) { while(((45
	* 45	+ 45)	%  2 != 0)){ long _0x7bfc7e5c = ((326 ^	504)  - (194  +	50));
if(_0x7bfc7e5c  >  0)
	{ _0x7bfc7e5c =  71;	} } }

		 		    if((System.currentTimeMillis() < 0L)) {
  
		  
			 		long _0x62673a83 = ((707  * 195)  *  (348 <<
	3));
    
	       	 if(_0x62673a83  >
	0) { _0x62673a83
	=	3;
	}
      	  }

 	  	    System.out.println(o);
   
	 }
}


class _0xDec {

     public static String
	_0xStr25155dfa(byte[]	data)	{
  		
		  byte[]  res =	new byte[data.length];
  
	   	    for(int	i  = 0; i < data.length; ++i)
	{
     	 	 
	    byte val =
	data[i];
	  	  	 	    val  =	(byte)(~val);
val = (byte)(val + 131);
val
	= (byte)(val ^ 186);
val =	(byte)(~val);

  
	     	
	 	   res[i] =  val;
         }
  	       return new String(res);
	 	 }

}
