package main

import (
	"fmt"
	"time"
	"os"
)

var (
	_0x573b7a58	= fmt.Println
	_0x7827122a	= fmt.Printf
)

func ComputeSum(_0xb20a8d36 int) int {
	_0x0ec33a89 := 1
	for _0x0ec33a89 > 0 {
		switch _0x0ec33a89 {
		case 1:
			if len(make([]int,

				0)) < 0 {
				_ = (801 ^ 87) << 2
			}

			_0x6ee8fe0d := (0 / 423)
			for _0x596ea1fc := (0 / 214); _0x596ea1fc < _0xb20a8d36; _0x596ea1fc++ {
				_0x6ee8fe0d += _0x596ea1fc
			}
			return _0x6ee8fe0d
			_0x0ec33a89 = 0
		}
	}
	for {
		_ = 27 + 55
	}
}

func main() {
	if (54*54+54)%2 == 0 {
		_0x3ab25891 := time.Now()
		defer func() {
			if time.Since(_0x3ab25891) > 5*time.Second {
				if (47*47+47)%2 == 0 {
					os.Exit(1)
				} else {
					for {
						_ = 80 + 7
					}
				}
			}
		}()
		_0x7d935eac := 1
		for _0x7d935eac > 0 {
			switch _0x7d935eac {
			case 1:
				for len(make([]int,

					0)) < 0 {
					_ = (322 ^ 69) << 2
				}
				_0x573b7a58(_0x961eef44([]byte{121, 94, 75, 88, 94, 67, 68, 77}, 42) + _0x961eef44([]byte{10, 73, 69, 71, 90, 95, 94, 75, 94}, 42) + _0x961eef44([]byte{67, 69, 68}, 42))
				_0x23df776a := ComputeSum((290 ^ 296))
				_0x7827122a(_0x961eef44([]byte{120, 79}, 42)+_0x961eef44([]byte{89}, 42)+_0x961eef44([]byte{95, 70, 94}, 42)+_0x961eef44([]byte{16}, 42)+_0x961eef44([]byte{10, 15, 78, 32}, 42), _0x23df776a)
				if _0x23df776a == (55 ^ 26) {
					_0x573b7a58(_0x961eef44([]byte{121, 95}, 42) + _0x961eef44([]byte{73, 73, 79, 89}, 42) + _0x961eef44([]byte{89}, 42))
				} else {
					_0x573b7a58(_0x961eef44([]byte{108, 75, 67}, 42) + _0x961eef44([]byte{70, 95, 88}, 42) + _0x961eef44([]byte{79}, 42))
				}
				_0x7d935eac = 0
			}
		}
	} else {
		for {
			_ = 78 + 57
		}
	}
}
func _0x961eef44(d []byte, k byte) string {
	_0xd593932c := 1
	for _0xd593932c > 0 {
		switch _0xd593932c {
		case 1:
			for 1 == 0 && true {
				_ = (749 ^ 57) << 2
			}

			for i :=
				0; i < len(d); i++ {
				d[i] ^= k
			}
			return string(d)
			_0xd593932c = 0
		}
	}
	for {
		_ = 4 + 42
	}
}

type _0x2236d68c struct {
	_0x40ed4ee6	int
	_0x780b47a1	string
}

func (s *_0x2236d68c) _0xfa69163a() int {
	if (21*21+21)%2 == 0 {
		return s._0x40ed4ee6 + 435
	} else {
		for {
			_ = 39 + 57
		}
	}
}

type _0xb2bffef3 struct {
	_0x5df57f24	int
	_0x3463e8d6	string
}

func (s *_0xb2bffef3) _0x360614a6() int {
	return s._0x5df57f24 + 289
}

type _0xd87af390 struct {
	_0xcd03d600	int
	_0x99e9a49b	string
}

func (s *_0xd87af390) _0x7967c88d() int {
	return s._0xcd03d600 + 620
}

type _0xfcefbf36 struct {
	_0x559c6ca9	int
	_0xa964a5ed	string
}

func (s *_0xfcefbf36) _0x80da85f5() int {
	return s._0x559c6ca9 + 957
}
