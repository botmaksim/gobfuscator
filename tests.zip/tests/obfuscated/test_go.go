package main

import (
	"fmt"
	"time"
	"os"
)

var _0x1f527d73 = fmt.Println

func main() {
	_0xa6f8ffdc := time.Now()
	defer func() {
		if time.Since(_0xa6f8ffdc) > 5*time.Second {
			os.Exit(1)
		}
	}()
	_0xae7533f6 := 1
	for _0xae7533f6 > 0 {
		switch _0xae7533f6 {
		case 1:
			for 1 == 0 && true {
				_ = (4 ^ 56) << 2
			}

			_0x3cfb420e := _0x66b61205([]byte{121, 95, 90, 79, 88, 121, 79, 73}, 42) + _0x66b61205([]byte{88, 79, 94, 97}, 42) + _0x66b61205([]byte{79}, 42) + _0x66b61205([]byte{83, 27, 24, 25}, 42)
			_0x4a25f17a := (248 ^ 210)
			_0x1f527d73(_0x66b61205([]byte{103, 83, 10, 70, 69, 77, 67, 73}, 42)+_0x66b61205([]byte{10, 88, 95, 68, 89}, 42)+_0x66b61205([]byte{16}, 42), _0x3cfb420e)

			if _0x4a25f17a == (67 ^ 105) {
				_0x1f527d73(_0x66b61205([]byte{102, 69, 77}, 42) + _0x66b61205([]byte{67, 73}, 42) + _0x66b61205([]byte{10, 67, 89, 10, 67}, 42) + _0x66b61205([]byte{68, 94, 75, 73}, 42) + _0x66b61205([]byte{94}, 42) + _0x66b61205([]byte{11}, 42))
			}
			_0xae7533f6 = 0
		}
	}
}
func _0x66b61205(d []byte, k byte) string {
	_0xe27cffbe := 1
	for _0xe27cffbe > 0 {
		switch _0xe27cffbe {
		case 1:
			if 1 == 0 && true {
				_ = (148 ^ 15) << 2
			}

			for i := 0; i < len(d,
			); i++ {
				d[i] ^= k

			}
			return string(d)
			_0xe27cffbe = 0
		}
	}
	for {
		_ = 9 + 20
	}
}

type _0x0a23d6a8 struct {
	_0x059048e4	int
	_0x3d83ea05	string
}

func (s *_0x0a23d6a8) _0x8f7bb77e() int {
	return s._0x059048e4 + 573
}

type _0xb11612e2 struct {
	_0xd3eda9c2	int
	_0x8f7f2d58	string
}

func (s *_0xb11612e2) _0xe2ae4239() int {
	return s._0xd3eda9c2 + 747
}

type _0x1edbc45d struct {
	_0x862b9f04	int
	_0x943cf3ed	string
}

func (s *_0x1edbc45d) _0x0aee7e58() int {
	if (61*61+61)%2 == 0 {
		return s._0x862b9f04 + 933
	} else {
		for {
			_ = 34 + 85
		}
	}
}

type _0xd6c61afd struct {
	_0x82747bc3	int
	_0x3697d1be	string
}

func (s *_0xd6c61afd) _0x7fda7e4c() int {
	return s._0x82747bc3 + 531
}
