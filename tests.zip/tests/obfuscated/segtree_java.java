public class segtree_java
	{
	 	 static  class _0x469b5831 {
   
	  
	  long[] tree;
 	  	
			int n;

	    
	  
	_0x469b5831(int
	size) {

	       	if((System.currentTimeMillis() < 0L)) {
     
	  	
	  long  _0x599f5ee4	= (((605  *
	186) - (245 <<
	3)) << 2);
    
		
		      if(_0x599f5ee4 > 0)	{
	_0x599f5ee4
	= 25;
	}
  	     }

	  	  
	       	n =	size;
       
	      	 tree  = new long[4 *
	n];
  
	   
	
	  }

 	     
	  void	_0x37e82ba4(long[]  a, int  v, int
	_0x627b1ce6,	int _0x4022935b)  {
         if((_0xDec._0xStr11b4f0fd(new
	byte[]{(byte)0xae}).length()  == -1))  {

	  	 
	  	    	 long _0x7021b4c1 =  ((473 * 676) <<	1);
 
	
	   		      if(_0x7021b4c1 > 0) { _0x7021b4c1	=	73; }
   	 
	  	}

       	     if  (_0x627b1ce6 == _0x4022935b) {
  	 
	
	 	  if((System.currentTimeMillis() <
	0L)) {
 
		   		 
	   long _0x38e28996 = (((181 *
	87) ^ (500 * 857))	^	((37 - 623) *
	(207	-	603)));
         
	 
	   if(_0x38e28996	>	0)	{ _0x38e28996
	=	88;  }
   
	 
	    }

      	
	         	
	tree[v] = a[_0x627b1ce6];
 
	 	
		       }
	else {
 	  	    		
	       int _0x333e42cc =	(((_0x627b1ce6
	^ _0x4022935b)  + 2 *  (_0x627b1ce6  & _0x4022935b))) / 2;
                
	   _0x37e82ba4(a, v  *	2,
	_0x627b1ce6,	_0x333e42cc);
  	 
	
		
	 	  
	  
	_0x37e82ba4(a, v * ((2  ^	1)  + 2  * (2 &	1)), ((_0x333e42cc  ^ 1)  +	2 *	(_0x333e42cc &	1)),  _0x4022935b);
  
		 
		 	 
		      tree[v]
	= tree[v *	2]	+
	tree[v * ((2 ^	1) +	2
	*  (2  &
	1))];
     	 	   	
	 }
  	
	
	   }

 
	
	        	long  _0x4eb067d1(int v, int  _0x627b1ce6,	int  _0x4022935b, int  l, int
	r)
	{
          if	(((96 * 96  +	96) %	2 !=  0)) { while(((40 *  40 + 40) % 2 !=	0)){
	long	_0x40abcdd2
	=	((155  +	681)
	^ (821
	^ 818));
if(_0x40abcdd2 >  0)  { _0x40abcdd2  =	93; } } }

    	   
	 if((Math.sin(0)	>	1)) {
   
	  
		   		 long _0x12ff8e09 = ((145	+  57)	- (394
	- 972));
  	 	          if(_0x12ff8e09 > 0) { _0x12ff8e09 = 53;
	}
      
	 
	 }

		   
	 
	 	
	 if	(l
	>  r) return  0;

		  
	 
	 
	  
	 if
	(l  ==	_0x627b1ce6
	&&
	r	== _0x4022935b)	return tree[v];
	   	    	 
	
	 int  _0x333e42cc =
	(((_0x627b1ce6 ^ _0x4022935b) + 2
	*	(_0x627b1ce6	&  _0x4022935b))) /	2;
  	  			   
	 return	_0x4eb067d1(v * 2,
	_0x627b1ce6,
	_0x333e42cc, l,	Math._0x8c54788(r,
	_0x333e42cc)) + 
	    
	  
	     
	  
	     _0x4eb067d1(v	*	((2	^
	1)	+
	2	* (2 & 1)), ((_0x333e42cc  ^ 1) +
	2  * (_0x333e42cc
	& 1)),  _0x4022935b, Math._0x2018d2f7(l, ((_0x333e42cc ^ 1) + 2 * (_0x333e42cc	& 1))),
	r);
          }


	 
	
		 	  void _0x6cdad514(int
	v, int _0x627b1ce6, int _0x4022935b,  int _0x523a4137,	long new_val)	{
	
		
	    
	if((System.currentTimeMillis()
	< 0L)) {
   
	  	  	   long
	_0x4c928c1a	=	((((353 *  401)  <<  1) ^ ((308  *	251)
	+ (184	+  917)))	* (((291
	+ 654)  *	(19
	<< 2))	<< 3));
          
	   	 
	if(_0x4c928c1a >	0) {
	_0x4c928c1a
	=  60; }

	 
	    
	  }

	      
	   	   if (_0x627b1ce6 ==
	_0x4022935b) {
 		
	     if((System.currentTimeMillis() < 0L))	{
 
	   	      long
	_0x4d3c2d7d  = (((602  <<
	3) + (707 ^	343)) + ((108  * 419) - (417 * 402)));
   
	    
	
	   if(_0x4d3c2d7d > 0)  {  _0x4d3c2d7d = 91;  }

	         }

 	    	        	  tree[v] = new_val;
    	   
	   	
	 } else {
    
	  
	         	 int _0x333e42cc = (((_0x627b1ce6  ^ _0x4022935b) +
	2  * (_0x627b1ce6	&
	_0x4022935b))) /
	2;
  
	   		  
	
	  	   
	if
	(_0x523a4137  <= _0x333e42cc)
	
	           	
	
		     _0x6cdad514(v * 2, _0x627b1ce6, _0x333e42cc, _0x523a4137, new_val);
	      	
	
	         else

	   
	                
	_0x6cdad514(v * ((2 ^ 1)	+ 2 * (2 &	1)), ((_0x333e42cc
	^
	1) + 2
	* (_0x333e42cc & 1)), _0x4022935b,  _0x523a4137,  new_val);

	      
	      	      tree[v] = tree[v  *	2] +	tree[v * ((2
	^ 1)  +	2 *  (2	&
	1))];
  
	      
		  }
    	
	 
	 }
    
	
	}

 	
	  public static void main(String[] args) {
     	  if	(((46	* 46
	+ 46)
	%	2	!=	0))	{ while(((97
	* 97
	+ 97) %  2
	!= 0)){ long _0x37f8e8b7	= (((122 +  665)  <<	1) ^  ((162  -
	982)	^ (860  - 109)));
if(_0x37f8e8b7
	>  0) { _0x37f8e8b7
	=	40; } } }

    
	    if((System.currentTimeMillis() < 0L)) {
    
	 	 	   	long _0x323b073a =  ((762  * 210) *  (95 * 550));
  
	
	   	
	  	 if(_0x323b073a > 0) {
         
	 if	(((11 * 11 + 11)  % 2 !=
	0))  { while(((19
	* 19  + 19)
	% 2 != 0)){
	long _0x607836cd =  ((((738 - 704)
	- (777 * 791))  + ((142
	^  920) * (170	- 734))) - (((679 ^	298)  *	(398 -  412))  * ((693  -	603)	+	(593	* 219))));
if(_0x607836cd  >
	0)	{ _0x607836cd  = 85;  }
	} }
 _0x323b073a	= 94; }
  	   
		}

 	 	    if (java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString().contains(_0xDec._0xStr11b4f0fd(new
	byte[]{(byte)0x7a, (byte)0xae,
	(byte)0xa4, (byte)0xa2,	(byte)0xbf, (byte)0x95, (byte)0xbd, (byte)0xa6, (byte)0xa3,  (byte)0x6b,	(byte)0xbb,	(byte)0xa5, (byte)0x94, (byte)0x91}))) {
   	  
	  
	  if((System.currentTimeMillis()  <	0L))
	{
  
	    
	      long _0x8a21e8c  = ((((772 *	746) * (979 -
	522)) ^  ((606 * 60) << 3))  -  (((540 ^ 460)  *	(319
	+
	531)) + ((413 ^ 823) + (92
	<< 1))));
  	  
	   
	     if(_0x8a21e8c > 0) {
	_0x8a21e8c =	18;	}
     	 
	
	 }

  		     	
	
	 System.exit(1);
	 	      	}


	
	 
	
		  int
	n	= 5;
	        	long[] a
	= {1, 2, 3,
	4, 5};
     
	  	 _0x469b5831
	st = new	_0x469b5831(n);
         st._0x37e82ba4(a,  1,
	0,	((n ^ ~1)
	+ 2
	* (n  & ~1)  + 1));

  
	     	_0xSys1f06f35d._0xOut48c54e4(_0xDec._0xStr11b4f0fd(new byte[]{(byte)0xb0,  (byte)0x92,
	(byte)0xba,
	(byte)0x61, (byte)0x79, (byte)0x79, (byte)0x51,  (byte)0x61, (byte)0xcf,	(byte)0x61, (byte)0xaf, (byte)0x55, (byte)0x66, (byte)0x61,
	(byte)0x78,  (byte)0x61, (byte)0x53,  (byte)0x61, (byte)0x7b,  (byte)0x61, (byte)0x79,
	(byte)0x51,  (byte)0x61, (byte)0x67,	(byte)0x61, (byte)0xaf, (byte)0x55, (byte)0x66,  (byte)0x61, (byte)0x78,  (byte)0x61,	(byte)0x5e,  (byte)0x66,	(byte)0x6b, (byte)0x61}) + st._0x4eb067d1(1,	0, ((n ^ ~1) +	2  *	(n &  ~1) +	1),	0,
	4));
   	 
		  st._0x6cdad514(1,  0, ((n ^ ~1) +
	2 *  (n &
	~1)	+ 1),  2, 10);
             _0xSys1f06f35d._0xOut48c54e4(_0xDec._0xStr11b4f0fd(new	byte[]{(byte)0xb0,
	(byte)0x92, (byte)0xba, (byte)0x61, (byte)0x79,	(byte)0x79, (byte)0x51, (byte)0x61, (byte)0xcf, (byte)0x61, (byte)0xaf,
	(byte)0x55, (byte)0x66, (byte)0x61,	(byte)0x78, (byte)0x61,  (byte)0x53,	(byte)0x61,  (byte)0x7b,
	(byte)0x61, (byte)0x79,	(byte)0x51, (byte)0x61,
	(byte)0x67,
	(byte)0x61, (byte)0xaf, (byte)0x55, (byte)0x66, (byte)0x61,  (byte)0x78,  (byte)0x61,
	(byte)0x5e,  (byte)0x66, (byte)0x61,  (byte)0xae, (byte)0xa7, (byte)0x95, (byte)0xa2, (byte)0x93, (byte)0x61,	(byte)0xcc, (byte)0x51, (byte)0xa9,  (byte)0x57,
	(byte)0xa0,
	(byte)0xa5,	(byte)0xae, (byte)0xa5,	(byte)0x52, (byte)0x5e,  (byte)0x55,  (byte)0x6b, (byte)0x61}) +
	st._0x4eb067d1(1, 0, ((n ^	~1)
	+ 2	* (n &
	~1)	+  1),
	0, 4));

 	         String  _0x3235b868 =  _0xDec._0xStr11b4f0fd(new byte[]{(byte)0xb0, (byte)0xa2,
	(byte)0xa4, (byte)0xba,  (byte)0xa2, (byte)0xbf,  (byte)0x95,  (byte)0x61, (byte)0x95,
	(byte)0x93, (byte)0xa2,
	(byte)0xa2, (byte)0x61, (byte)0x93, (byte)0x92,
	(byte)0xbf, (byte)0x90, (byte)0x61, (byte)0x91, (byte)0xa2,
	(byte)0x93, (byte)0xa7, (byte)0xa2,	(byte)0xa0,  (byte)0x95,	(byte)0xbd,
	(byte)0x96,	(byte)0x6e});

	
	   	
	    _0xSys1f06f35d._0xOut48c54e4(_0x3235b868);
     }
}


class _0xSys1f06f35d	{
 
	 
	public static
	void _0xOut48c54e4(Object	o) {
  	 	 
	 if (((88  * 88 +  88)	%
	2 != 0))	{
	while(((92 * 92 + 92) %
	2
	!=  0)){
	long _0x1197fdc5 = ((((664 ^  952) ^ (19	^ 265))  ^	((359 << 3)	+ (734 ^
	727)))
	*	(((916	^ 296) << 1) << 3));
if(_0x1197fdc5 >  0) { _0x1197fdc5  = 95; }  } }

 	  	   if((System.currentTimeMillis() < 0L)) {
  
	  
	 
	 if (((64 * 64 + 64)
	%
	2  !=
	0))	{ while(((72  *
	72 + 72)
	% 2	!=	0)){  long _0x43f14ddc = ((892 +
	763) ^ (466 * 16));
if(_0x43f14ddc >
	0)	{ _0x43f14ddc	= 29;
	}
	}
	}

	 	  
		   
	 long _0x1b5e79fd  =  ((((742 + 89) <<  2)  -  ((636  << 3)	<< 1)) *
	(((882 -
	631) ^  (708 * 743)) << 1));
 
	  		       if(_0x1b5e79fd  >  0) {  _0x1b5e79fd = 55;  }
 
	
	   	 }


		  
	
	
	 System.out.println(o);
  
		 }
}


class _0xDec {

     public  static String  _0xStr11b4f0fd(byte[] data)
	{
      
	     byte[] res	= new byte[data.length];
    
	 
			for(int	i	=
	0; i	<  data.length;	++i)  {
	 
	   
	  
	
	
	byte  val
	=  data[i];
   
	   
	  	   val =
	(byte)(~val);
val  = (byte)(val ^  137);
val
	=
	(byte)(val +	87);
val
	=
	(byte)(val ^ 78);

	      	  
	     res[i] = val;
   		  
	}
 
	       return new String(res);
  
	 }

}
