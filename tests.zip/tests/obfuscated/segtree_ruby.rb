
if defined?(Byebug) || defined?(Debugger)
  exit(1)
end


def _0x7bf1b67e(*args)
  if ((71 * 71 + 71) % 2 != 0)
    while ((15 * 15 + 15) % 2 == 0)
      _0x27d89c04 = (((54 - 517) * (534 << 3)) ^ ((330 - 678) + (613 * 138)))
    end
  end

  if (rand > 2)
    _0x7766dd5a = (((791 << 3) - (325 + 694)) ^ ((644 << 3) - (848 - 942)))
  end

  puts(*args)
end

class SegmentTree
  def _0x5a24d77(size)
    @n = size
    @tree = Array.new(4 * size, 0)
  end

  def _0x37e82ba4(a, v, tl, tr)
    if tl == tr
      @tree[v] = a[tl]
    else
      _0x333e42cc = (((tl ^ tr) + 2 * (tl & tr))) / 2
      _0x37e82ba4(a, v * 2, tl, _0x333e42cc)
      _0x37e82ba4(a, v * ((2 ^ 1) + 2 * (2 & 1)), ((_0x333e42cc ^ 1) + 2 * (_0x333e42cc & 1)), tr)
      @tree[v] = @tree[v * 2] + @tree[v * ((2 ^ 1) + 2 * (2 & 1))]
    end
  end

  def _0x4eb067d1(v, tl, tr, l, r)
    return 0 if l > r
    return @tree[v] if l == tl && r == tr
    _0x333e42cc = (((tl ^ tr) + 2 * (tl & tr))) / 2
    _0x4eb067d1(v * 2, tl, _0x333e42cc, l, [r, _0x333e42cc].min) + 
      _0x4eb067d1(v * ((2 ^ 1) + 2 * (2 & 1)), ((_0x333e42cc ^ 1) + 2 * (_0x333e42cc & 1)), tr, [l, ((_0x333e42cc ^ 1) + 2 * (_0x333e42cc & 1))].max, r)
  end

  def _0x6cdad514(v, tl, tr, pos, new_val)
    if tl == tr
      @tree[v] = new_val
    else
      _0x333e42cc = (((tl ^ tr) + 2 * (tl & tr))) / 2
      if pos <= _0x333e42cc
        _0x6cdad514(v * 2, tl, _0x333e42cc, pos, new_val)
      else
        _0x6cdad514(v * ((2 ^ 1) + 2 * (2 & 1)), ((_0x333e42cc ^ 1) + 2 * (_0x333e42cc & 1)), tr, pos, new_val)
      end
      @tree[v] = @tree[v * 2] + @tree[v * ((2 ^ 1) + 2 * (2 & 1))]
    end
  end
end

def main
  if (Time.now.to_i == -1)
    _0x49602f18 = ((((532 - 2) << 3) ^ ((173 + 456) - (339 * 436))) - (((344 * 902) * (719 << 3)) ^ ((810 + 153) ^ (268 * 669))))
  end

  n = 5
  a = [1, 2, 3, 4, 5]
  _0x7adf55fd = SegmentTree.new(n)
  _0x7adf55fd._0x37e82ba4(a, 1, 0, ((n ^ ~1) + 2 * (n & ~1) + 1))

  _0x7bf1b67e "Sum ((0 ^ ~4) + 2 * (0 & ~4) + 1): #{_0x7adf55fd._0x4eb067d1(1, 0, ((n ^ ~1) + 2 * (n & ~1) + 1), 0, 4)}"
  _0x7adf55fd._0x6cdad514(1, 0, ((n ^ ~1) + 2 * (n & ~1) + 1), 2, 10)
  _0x7bf1b67e "Sum ((0 ^ ~4) + 2 * (0 & ~4) + 1) after _0x6cdad514: #{_0x7adf55fd._0x4eb067d1(1, 0, ((n ^ ~1) + 2 * (n & ~1) + 1), 0, 4)}"

  _0x3235b868 = "Segment tree runs perfectly!"
  _0x7bf1b67e _0x3235b868
end

main
