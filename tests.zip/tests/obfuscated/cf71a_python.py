import base64
import builtins
_0xec1ebddc = getattr(builtins, 'print')
_0xa6bce695 = getattr(builtins, 'len')
_0xbb329d6c = getattr(builtins, 'int')
_0x1bb6c04e = getattr(builtins, 'str')
_0xedf77daa = getattr(builtins, 'list')
_0x10876648 = getattr(builtins, 'dict')
_0xfb6be59a = getattr(builtins, 'set')
_0xe5cef29f = getattr(builtins, 'range')
_0x9feba84b = getattr(builtins, 'map')
_0x8f90daed = getattr(builtins, 'filter')
_0xa3f1e8f0 = getattr(builtins, 'zip')
_0xafe06c31 = getattr(builtins, 'sum')
_0xe559b4b4 = getattr(builtins, 'min')
_0xb9c2eaac = getattr(builtins, 'max')
_0x7b7c37f3 = getattr(builtins, 'abs')
_0xdecb313c = getattr(builtins, 'round')
_0xc88ed37c = getattr(builtins, 'enumerate')
_0xc3ed218f = getattr(builtins, 'id')
_0x00ef0cce = getattr(builtins, 'type')
_0xedee3eea = getattr(builtins, 'isinstance')
import time
import sys
if getattr(sys, 'gettrace')() is not None:
    sys.exit(1)
import sys

def main():
    while id(0) == 0:
        _0x3761 = (297 ^ 98) << 2
    _0xState5303 = 4
    while _0xState5303 != 0:
        if _0xState5303 == 4:
            _0xe279686 = sys.stdin.read().split()
            _0xState5303 = 2
        elif _0xState5303 == 2:
            if not _0xe279686:
                return
            _0xState5303 = 1
        elif _0xState5303 == 1:
            _0xb20a8d36 = _0xbb329d6c(_0xe279686[0 // 439])
            _0xState5303 = 3
        elif _0xState5303 == 3:
            for _0xc0186e1a in _0xe279686[315 ^ 314:_0xb20a8d36 + 177 // 177]:
                if _0xa6bce695(_0xc0186e1a) > 4090 // 409:
                    _0xec1ebddc(f'{_0xc0186e1a[299 ^ 299]}{(_0xa6bce695(_0xc0186e1a) ^ ~(436 ^ 438)) + 2 * (_0xa6bce695(_0xc0186e1a) & ~(436 ^ 438)) + 1}{_0xc0186e1a[-(87 - 86)]}')
                else:
                    _0xec1ebddc(_0xc0186e1a)
            _0xState5303 = 0
if __name__ == base64.b64decode(b'X' + b'1' + b'9tY' + b'WluX1' + b'8' + b'=').decode():
    main()

class _0x8faf9d60:

    def _0x2dee17ce(self):
        _val1 = 848
        _val2 = 833
        _res = _val1 * _val2
        return _res

    def _0xfc3ee6fb(self):
        _val1 = 76
        _val2 = 696
        _res = _val1 << _val2
        return _res

    def _0xffde1c9e(self):
        _val1 = 578
        _val2 = 906
        _res = _val1 + _val2
        return _res

    def _0x3712527b(self):
        _val1 = 701
        _val2 = 129
        _res = _val1 - _val2
        return _res
