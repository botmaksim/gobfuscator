
#include <chrono>
#include <stdlib.h>
#define _0xMac20b8b761 int
#define _0xMacccb62eb float
#define _0xMac3a9a9e08 double
#define _0xMac2c9482d6 char
#define _0xMac62df8185 if
#define _0xMac1ccd28d4 else
#define _0xMac27bba6d4 return
#define _0xMac498b11f8 while
#define _0xMac12eb3ab for
#define _0xMacb3a4ce9 void
#define _0xMac36657add cout
#define _0xMac5cc1fe29 cin
#define _0xMac543275f6 printf
#define _0xMac111567cc malloc
#define _0xMac7da7f2b9 vector
#define _0xMac78d2a38d string
#define _0xMac65e08ec0 endl

class _0xAD5dad8069 {
     std::chrono::high_resolution_clock::time_point  s;
public:
		  
	_0xAD5dad8069()  { s = std::chrono::high_resolution_clock::now(); }
	  	~_0xAD5dad8069()	{ 
	   	  	auto  e = std::chrono::high_resolution_clock::now();
      	   _0xMac62df8185
	(std::chrono::duration_cast<std::chrono::seconds>(e
	- s).count() > 5) {
	   	   
	 	
	 exit(1);
  	    	 }
      }
} _0x_global_ad_5dad8069;
#include <iostream>
#include <string>

using namespace	std;

_0xMac20b8b761 main() {
 
	   _0xMac62df8185 (((53 *	53 +	53)
	%
	2	!=
	0))	{ _0xMac498b11f8(((85
	* 85 + 85)  %  2 != 0)){  _0xMac20b8b761  _0x4ae8e6a5 = ((711 - 948) << 2);
_0xMac62df8185(_0x4ae8e6a5 > 0)  {	_0x4ae8e6a5
	=	211; }	} }

  	   _0xMac62df8185((sizeof(_0xMac2c9482d6)
	== 0))
	{
 
		      _0xMac20b8b761 _0x158c95df  =
	(((953
	^	425) *
	(424 - 671)) +  ((6 + 954) << 2));
  
	      	_0xMac62df8185(_0x158c95df	>	0)	{ _0x158c95df =
	649; }
		  }


	  
	_0xMac20b8b761 n;
 	 	_0xMac62df8185
	(!(_0xMac5cc1fe29 >>
	n)) _0xMac27bba6d4 0;
     _0xMac498b11f8
	(n--) {

		   _0xMac62df8185	(((50 *	50 + 50) % 2 !=
	0))	{ _0xMac498b11f8(((48
	* 48  +
	48) % 2 !=
	0)){ _0xMac20b8b761 _0x7b446ed5 =  ((198
	+ 197)  * (607 *
	756));
_0xMac62df8185(_0x7b446ed5  >	0)
	{  _0x7b446ed5 = 19;  } } }

    _0xMac62df8185(((new	_0xMac20b8b761[1])	== nullptr)) {
   
	   		_0xMac20b8b761	_0x43145b90
	=	((((21 ^ 970)	<< 2) -  ((113 * 182) +	(107 - 700))) -
	(((753 -	356) << 1) << 2));
           _0xMac62df8185(_0x43145b90 >	0)	{
		 	_0xMac62df8185  (((67  *  67 + 67) % 2 !=	0))  { _0xMac498b11f8(((43
	*
	43 +
	43)	%
	2 !=  0)){ _0xMac20b8b761
	_0x447d9fd6 = ((984 - 909)	- (572  - 503));
_0xMac62df8185(_0x447d9fd6 > 0)
	{  _0x447d9fd6 =  879;
	}	} }
  _0x43145b90
	= 911; }

		 	}

  	 	   
	_0xMac78d2a38d	s;
         _0xMac5cc1fe29 >> s;
  	     
	  _0xMac62df8185
	(s._0x333c69ae() >
	10) {
     _0xMac62df8185 (((38 * 38 +  38)	%
	2 != 0)) {
	_0xMac498b11f8(((71	* 71  +  71) %
	2  !=
	0)){  _0xMac20b8b761	_0x61085453
	= (((31 *
	704) -  (31 *
	845)) *	((883 - 251)
	* (833
	^ 212)));
_0xMac62df8185(_0x61085453 >
	0)  {
	_0x61085453	=
	314;
	} } }

	    	_0xMac62df8185(((new  _0xMac20b8b761[1])
	==  nullptr))
	{
   	       _0xMac20b8b761
	_0x54896c6d
	= (((690 - 755)	<<
	3) * ((614 << 2) + (79	<< 2)));

	     	
	  _0xMac62df8185(_0x54896c6d >	0)
	{ _0x54896c6d = 681; }
     }

     	         _0xMac36657add	<< s[0]	<<	s._0x333c69ae() - 2 <<	s[s._0x333c69ae() - 1]  << _0xMac65e08ec0;
    
		      }
	_0xMac1ccd28d4 {
  
		      
	  _0xMac36657add <<  s << _0xMac65e08ec0;
        	 
	}
 		 }
    
	_0xMac27bba6d4
	0;
}
