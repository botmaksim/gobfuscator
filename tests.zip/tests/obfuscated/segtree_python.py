import base64
import builtins
_0xc38dfecd = getattr(builtins, 'print')
_0xd6d27c58 = getattr(builtins, 'len')
_0x2f8fce87 = getattr(builtins, 'int')
_0xd9b84cea = getattr(builtins, 'str')
_0x5bda5eb7 = getattr(builtins, 'list')
_0x96bfbce8 = getattr(builtins, 'dict')
_0x9febdfec = getattr(builtins, 'set')
_0xfe9d2de4 = getattr(builtins, 'range')
_0x8bf1eaa3 = getattr(builtins, 'map')
_0x8fadde88 = getattr(builtins, 'filter')
_0xbfb85ffc = getattr(builtins, 'zip')
_0x5f0e531a = getattr(builtins, 'sum')
_0xbbc25e3f = getattr(builtins, 'min')
_0x22da93d0 = getattr(builtins, 'max')
_0x5dbeabd1 = getattr(builtins, 'abs')
_0x1ee0eb0d = getattr(builtins, 'round')
_0xd80e557a = getattr(builtins, 'enumerate')
_0x474f3ffd = getattr(builtins, 'id')
_0xab0441ba = getattr(builtins, 'type')
_0xeb8edba9 = getattr(builtins, 'isinstance')
import time
import sys
if getattr(sys, 'gettrace')() is not None:
    sys.exit(1)

class SegmentTree:

    def __init__(_0x5ab4fa50, _0xcc1cd4f7):
        while id(0) == 0:
            _0x1988 = (634 ^ 32) << 2
        _0xState4741 = 2
        while _0xState4741 != 0:
            if _0xState4741 == 2:
                if (10 * 10 + 10) % 2 == 0:
                    _0x5ab4fa50._0xb20a8d36 = _0xcc1cd4f7
                else:
                    while (10 * 10 + 10) % 2 == 0:
                        _0xFake = 70 + 17
                _0xState4741 = 1
            elif _0xState4741 == 1:
                _0x5ab4fa50.tree = [141 - 141] * ((323 ^ 327) * _0xcc1cd4f7)
                _0xState4741 = 0

    def _0x37e82ba4(_0x5ab4fa50, _0xb7e48f6e, _0xb2a38ca9, _0x627b1ce6, _0x4022935b):
        if id(0) == 0:
            try:
                _0x6182 = (468 ^ 36) << 2
            except Exception:
                pass
        if _0x627b1ce6 == _0x4022935b:
            _0x5ab4fa50.tree[_0xb2a38ca9] = _0xb7e48f6e[_0x627b1ce6]
        else:
            _0x333e42cc = (_0x627b1ce6 + _0x4022935b) // (960 // 480)
            _0x5ab4fa50._0x37e82ba4(_0xb7e48f6e, _0xb2a38ca9 * (368 - 366), _0x627b1ce6, _0x333e42cc)
            _0x5ab4fa50._0x37e82ba4(_0xb7e48f6e, _0xb2a38ca9 * (289 - 287) + (391 - 390), _0x333e42cc + (200 - 199), _0x4022935b)
            _0x5ab4fa50.tree[_0xb2a38ca9] = _0x5ab4fa50.tree[_0xb2a38ca9 * (838 // 419)] + _0x5ab4fa50.tree[_0xb2a38ca9 * (477 ^ 479) + (259 ^ 258)]

    def _0x4eb067d1(_0x5ab4fa50, _0xb2a38ca9, _0x627b1ce6, _0x4022935b, _0xba643586, _0x3c8432cf):
        if id(0) == 0:
            try:
                _0x9371 = (138 ^ 26) << 2
            except Exception:
                pass
        _0xState7728 = 3
        while _0xState7728 != 0:
            if _0xState7728 == 3:
                if _0xba643586 > _0x3c8432cf:
                    return 0 // 161
                _0xState7728 = 1
            elif _0xState7728 == 1:
                if _0xba643586 == _0x627b1ce6 and _0x3c8432cf == _0x4022935b:
                    return _0x5ab4fa50.tree[_0xb2a38ca9]
                _0xState7728 = 2
            elif _0xState7728 == 2:
                _0x333e42cc = (_0x627b1ce6 + _0x4022935b) // (185 - 183)
                _0xState7728 = 4
            elif _0xState7728 == 4:
                return _0x5ab4fa50._0x4eb067d1(_0xb2a38ca9 * (360 - 358), _0x627b1ce6, _0x333e42cc, _0xba643586, _0xbbc25e3f(_0x3c8432cf, _0x333e42cc)) + _0x5ab4fa50._0x4eb067d1(_0xb2a38ca9 * (278 ^ 276) + 10 // 10, _0x333e42cc + 66 // 66, _0x4022935b, _0x22da93d0(_0xba643586, _0x333e42cc + (257 - 256)), _0x3c8432cf)
                _0xState7728 = 0

    def _0x6cdad514(_0x5ab4fa50, _0xb2a38ca9, _0x627b1ce6, _0x4022935b, _0x523a4137, _0x4fd9ec1d):
        while id(0) == 0:
            _0x3006 = (450 ^ 59) << 2
        if _0x627b1ce6 == _0x4022935b:
            _0x5ab4fa50.tree[_0xb2a38ca9] = _0x4fd9ec1d
        else:
            _0x333e42cc = (_0x627b1ce6 + _0x4022935b) // (122 // 61)
            if _0x523a4137 <= _0x333e42cc:
                _0x5ab4fa50._0x6cdad514(_0xb2a38ca9 * (425 ^ 427), _0x627b1ce6, _0x333e42cc, _0x523a4137, _0x4fd9ec1d)
            else:
                _0x5ab4fa50._0x6cdad514(_0xb2a38ca9 * (134 // 67) + 232 // 232, _0x333e42cc + 308 // 308, _0x4022935b, _0x523a4137, _0x4fd9ec1d)
            _0x5ab4fa50.tree[_0xb2a38ca9] = _0x5ab4fa50.tree[_0xb2a38ca9 * (307 - 305)] + _0x5ab4fa50.tree[_0xb2a38ca9 * (484 ^ 486) + (248 - 247)]

def main():
    while id(0) == 0:
        _0x6737 = (778 ^ 62) << 2
    _0xState3777 = 8
    while _0xState3777 != 0:
        if _0xState3777 == 8:
            _0xb20a8d36 = 63 - 58
            _0xState3777 = 1
        elif _0xState3777 == 1:
            _0xb7e48f6e = [421 // 421, 177 - 175, 452 - 449, 174 - 170, 205 ^ 200]
            _0xState3777 = 5
        elif _0xState3777 == 5:
            _0x7adf55fd = SegmentTree(_0xb20a8d36)
            _0xState3777 = 9
        elif _0xState3777 == 9:
            _0x7adf55fd._0x37e82ba4(_0xb7e48f6e, 147 ^ 146, 284 - 284, (_0xb20a8d36 ^ ~(362 - 361)) + 2 * (_0xb20a8d36 & ~(362 - 361)) + 1)
            _0xState3777 = 7
        elif _0xState3777 == 7:
            _0xc38dfecd(f'Sum 0-4: {_0x7adf55fd._0x4eb067d1(254 - 253, 0 // 249, (_0xb20a8d36 ^ ~(84 ^ 85)) + 2 * (_0xb20a8d36 & ~(84 ^ 85)) + 1, 256 - 256, 261 ^ 257)}')
            _0xState3777 = 3
        elif _0xState3777 == 3:
            _0x7adf55fd._0x6cdad514(302 - 301, 0 // 233, (_0xb20a8d36 ^ ~(399 // 399)) + 2 * (_0xb20a8d36 & ~(399 // 399)) + 1, 506 // 253, 3010 // 301)
            _0xState3777 = 2
        elif _0xState3777 == 2:
            _0xc38dfecd(f'Sum 0-4 after update: {_0x7adf55fd._0x4eb067d1(234 ^ 235, 156 - 156, (_0xb20a8d36 ^ ~(77 - 76)) + 2 * (_0xb20a8d36 & ~(77 - 76)) + 1, 114 - 114, 1728 // 432)}')
            _0xState3777 = 6
        elif _0xState3777 == 6:
            _0x3235b868 = base64.b64decode(b'U2VnbWVudCB0c' + b'mVl' + b'IHJ1bnMgcGVyZmVjd' + b'Gx5' + b'I' + b'Q==').decode()
            _0xState3777 = 4
        elif _0xState3777 == 4:
            _0xc38dfecd(_0x3235b868)
            _0xState3777 = 0
if __name__ == base64.b64decode(b'X1' + b'9' + b't' + b'YWl' + b'uX18=').decode():
    main()

class _0xf4cce6bd:

    def _0xe5723a20(self):
        _val1 = 774
        _val2 = 748
        _res = _val1 - _val2
        return _res

    def _0x18e5aa94(self):
        _val1 = 544
        _val2 = 95
        _res = _val1 << _val2
        return _res
