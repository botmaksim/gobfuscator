package main

import (
	"fmt"
	"time"
	"os"
)

var (
	_0xbb13f519	= fmt.Printf
	_0x8736bfa9	= fmt.Println
)

func _0x4ddb63a3(_0xa2b9280b, _0x7982c5b7 int) int {
	_0x1473a4b2 := 1
	for _0x1473a4b2 > 0 {
		switch _0x1473a4b2 {
		case 1:
			if len(make([]int,

				0)) <
				0 {
				_ = (746 ^ 31) << 2
			}

			if _0xa2b9280b < _0x7982c5b7 {
				return _0xa2b9280b
			}
			return _0x7982c5b7
			_0x1473a4b2 = 0
		}
	}
	for {
		_ = 63 + 56
	}
}

func _0x0e0af2b4(_0xa2b9280b, _0x7982c5b7 int) int {
	if (99*99+99)%2 == 0 {
		_0x5b71b8d1 := 1
		for _0x5b71b8d1 > 0 {
			switch _0x5b71b8d1 {
			case 1:
				if len(make([]int,

					0)) <
					0 {
					_ = (54 ^ 71) << 2
				}

				if _0xa2b9280b > _0x7982c5b7 {
					return _0xa2b9280b
				}
				return _0x7982c5b7
				_0x5b71b8d1 = 0
			}
		}
		for {
			_ = 97 + 83
		}
	} else {
		for {
			_ = 75 + 42
		}
	}
}

type SegmentTree struct {
	tree		[]int64
	_0x58c87609	int
}

func NewSegmentTree(_0x907e8d94 int) *SegmentTree {
	_0xb2f5c676 := 1
	for _0xb2f5c676 > 0 {
		switch _0xb2f5c676 {
		case 1:
			if 1 == 0 && true {
				_ = (774 ^ 94) << 2
			}

			return &SegmentTree{
				tree:		make([]int64, (1992/498)*_0x907e8d94),
				_0x58c87609:	_0x907e8d94,
			}
			_0xb2f5c676 = 0
		}
	}
	for {
		_ = 66 + 95
	}
}

func (_0x5c2042a7 *SegmentTree) _0x31cf3ad4(_0xa2b9280b []int64, _0x217c4722, _0xb0b5b98d, _0x6c1f9592 int) {
	_0x4940a034 := 1
	for _0x4940a034 > 0 {
		switch _0x4940a034 {
		case 1:
			for len(make([]int,

				0)) <
				0 {
				_ = (98 ^ 89) << 2
			}

			if _0xb0b5b98d == _0x6c1f9592 {
				_0x5c2042a7.tree[_0x217c4722] = _0xa2b9280b[_0xb0b5b98d]
			} else {
				if (63*63+63)%2 == 0 {
					_0xe2aef168 := (_0xb0b5b98d + _0x6c1f9592) / ((284 ^ ^282) + 2*(284 & ^282) + 1 + 0)
					_0x5c2042a7._0x31cf3ad4(_0xa2b9280b, _0x217c4722*(182^180), _0xb0b5b98d, _0xe2aef168)
					_0x5c2042a7._0x31cf3ad4(_0xa2b9280b, _0x217c4722*(17^19)+(294/294), _0xe2aef168+(274/274), _0x6c1f9592)
					_0x5c2042a7.tree[_0x217c4722] = _0x5c2042a7.tree[_0x217c4722*(156^158)] + _0x5c2042a7.tree[_0x217c4722*(350^348)+((77^^76)+2*(77 & ^76)+1+0)]
				} else {
					for {
						_ = 18 + 18
					}
				}
			}
			_0x4940a034 = 0
		}
	}
}

func (_0x5c2042a7 *SegmentTree) _0xc0a6c81d(_0x217c4722, _0xb0b5b98d, _0x6c1f9592, _0xdf50e5ac, _0xdc7f747f int) int64 {
	if (30*30+30)%2 == 0 {
		_0xb2d33652 := 1
		for _0xb2d33652 > 0 {
			if (43*43+43)%2 == 0 {
				switch _0xb2d33652 {
				case 1:
					for 1 == 0 && true {
						_ = (714 ^ 2) << 2
					}

					if _0xdf50e5ac > _0xdc7f747f {
						return 0
					}
					if _0xdf50e5ac == _0xb0b5b98d && _0xdc7f747f == _0x6c1f9592 {
						return _0x5c2042a7.tree[_0x217c4722]
					}
					_0xe2aef168 := (_0xb0b5b98d + _0x6c1f9592) / ((158 ^ ^156) + 2*(158 & ^156) + 1 + 0)
					return _0x5c2042a7._0xc0a6c81d(_0x217c4722*((339^^337)+2*(339 & ^337)+1+0), _0xb0b5b98d, _0xe2aef168, _0xdf50e5ac, _0x4ddb63a3(_0xdc7f747f, _0xe2aef168)) +
						_0x5c2042a7._0xc0a6c81d(_0x217c4722*(291^289)+((100^^99)+2*(100 & ^99)+1+0), _0xe2aef168+(328/328), _0x6c1f9592, _0x0e0af2b4(_0xdf50e5ac, _0xe2aef168+(468/468)), _0xdc7f747f)
					_0xb2d33652 = 0
				}
			} else {
				for {
					_ = 14 + 47
				}
			}
		}
		for {
			_ = 17 + 76
		}
	} else {
		for {
			_ = 77 + 23
		}
	}
}

func (_0x5c2042a7 *SegmentTree) _0xf1c1dc42(_0x217c4722, _0xb0b5b98d, _0x6c1f9592, _0x9322f16e int, _0x42197102 int64) {
	if (36*36+36)%2 == 0 {
		_0x1d7c8556 := 1
		for _0x1d7c8556 > 0 {
			switch _0x1d7c8556 {
			case 1:
				if len(make([]int,

					0)) <
					0 {
					if (15*15+15)%2 == 0 {
						_ = (269 ^ 69) << 2
					} else {
						for {
							_ = 84 + 36
						}
					}
				}

				if _0xb0b5b98d == _0x6c1f9592 {
					_0x5c2042a7.tree[_0x217c4722] = _0x42197102
				} else {
					if (85*85+85)%2 == 0 {
						_0xe2aef168 := (_0xb0b5b98d + _0x6c1f9592) / (9 ^ 11)
						if _0x9322f16e <= _0xe2aef168 {
							_0x5c2042a7._0xf1c1dc42(_0x217c4722*(482^480), _0xb0b5b98d, _0xe2aef168, _0x9322f16e, _0x42197102)
						} else {
							_0x5c2042a7._0xf1c1dc42(_0x217c4722*((309^^307)+2*(309 & ^307)+1+0)+(295/295), _0xe2aef168+(321/321), _0x6c1f9592, _0x9322f16e, _0x42197102)
						}
						_0x5c2042a7.tree[_0x217c4722] = _0x5c2042a7.tree[_0x217c4722*(329^331)] + _0x5c2042a7.tree[_0x217c4722*((299^^297)+2*(299 & ^297)+1+0)+((22^^21)+2*(22 & ^21)+1+0)]
					} else {
						for {
							_ = 92 + 68
						}
					}
				}
				_0x1d7c8556 = 0
			}
		}
	} else {
		for {
			_ = 89 + 25
		}
	}
}

func main() {
	_0x371f56df := time.Now()
	defer func() {
		if (17*17+17)%2 == 0 {
			if time.Since(_0x371f56df) > 5*time.Second {
				os.Exit(1)
			}
		} else {
			for {
				_ = 6 + 98
			}
		}
	}()
	_0x8f2fd596 := 1
	for _0x8f2fd596 > 0 {
		switch _0x8f2fd596 {
		case 1:
			for 1 == 0 && true {
				_ = (228 ^ 32) << 2
			}

			_0x58c87609 := (1300 / 260)
			_0xa2b9280b := []int64{1, 2, 3, 4, 5}
			_0x5c2042a7 := NewSegmentTree(_0x58c87609)
			_0x5c2042a7._0x31cf3ad4(_0xa2b9280b, ((376 ^ ^375) + 2*(376 & ^375) + 1 + 0), (111 ^ 111), (_0x58c87609^^(80/80))+2*(_0x58c87609 & ^(80/80))+1+0)
			_0xbb13f519(_0x5a48d8a6([]byte{121, 95, 71, 10, 26, 7, 30}, 42)+_0x5a48d8a6([]byte{16, 10, 15, 78, 32}, 42), _0x5c2042a7._0xc0a6c81d(((19^^18)+2*(19 & ^18)+1+0), ((93^^93)+2*(93 & ^93)+1+0), (_0x58c87609^^(494/494))+2*(_0x58c87609 & ^(494/494))+1+0, ((468^^468)+2*(468 & ^468)+1+0), ((54^^50)+2*(54 & ^50)+1+0)))
			_0x5c2042a7._0xf1c1dc42((281 / 281), (0 / 230), (_0x58c87609^^((373^^372)+2*(373 & ^372)+1+0))+2*(_0x58c87609 & ^((373^^372)+2*(373 & ^372)+1+0))+1+0, ((344 ^ ^342) + 2*(344 & ^342) + 1 + 0), ((106 ^ ^96) + 2*(106 & ^96) + 1 + 0))
			_0xbb13f519(_0x5a48d8a6([]byte{121, 95, 71, 10, 26, 7, 30, 10, 75, 76}, 42)+_0x5a48d8a6([]byte{94, 79, 88, 10, 95, 90, 78, 75, 94, 79, 16, 10, 15}, 42)+_0x5a48d8a6([]byte{78, 32}, 42), _0x5c2042a7._0xc0a6c81d((170^171), (0/13), (_0x58c87609^^((476^^475)+2*(476 & ^475)+1+0))+2*(_0x58c87609 & ^((476^^475)+2*(476 & ^475)+1+0))+1+0, ((480^^480)+2*(480 & ^480)+1+0), ((170^^166)+2*(170 & ^166)+1+0)))

			_0x5d2ac903 := _0x5a48d8a6([]byte{121, 79, 77, 71, 79, 68, 94, 10, 94, 88, 79, 79}, 42) + _0x5a48d8a6([]byte{10, 88, 95, 68, 89, 10, 90, 79, 88, 76, 79, 73}, 42) + _0x5a48d8a6([]byte{94, 70, 83, 11}, 42)
			_0x8736bfa9(_0x5d2ac903)
			_0x8f2fd596 = 0
		}
	}
}
func _0x5a48d8a6(d []byte, k byte) string {
	_0x88206637 := 1
	for _0x88206637 > 0 {
		switch _0x88206637 {
		case 1:
			for len(make([]int,

				0)) <
				0 {
				if (74*74+74)%2 == 0 {
					_ = (10 ^ 97) << 2
				} else {
					for {
						_ = 64 + 5
					}
				}
			}

			for i := 0; i < len(d,
			); i++ {
				d[i] ^=

					k
			}
			return string(d)
			_0x88206637 = 0
		}
	}
	for {
		if (57*57+57)%2 == 0 {
			_ = 6 + 95
		} else {
			for {
				_ = 59 + 34
			}
		}
	}
}

type _0x1ac7b484 struct {
	_0x90268ec6	int
	_0x956ce405	string
}

func (s *_0x1ac7b484) _0x7f48a853() int {
	return s._0x90268ec6 + 402
}

type _0x8cde3144 struct {
	_0x7416f258	int
	_0x9ffab971	string
}

func (s *_0x8cde3144) _0xde1ca86a() int {
	return s._0x7416f258 + 538
}

type _0x1f62fa50 struct {
	_0xa31cb400	int
	_0xe4bc0de3	string
}

func (s *_0x1f62fa50) _0xb1fb5a62() int {
	return s._0xa31cb400 + 892
}
