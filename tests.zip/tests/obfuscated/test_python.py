import base64
import builtins
_0x1ebdaf6e = getattr(builtins, 'print')
_0x4c1afaac = getattr(builtins, 'len')
_0x5d9bc952 = getattr(builtins, 'int')
_0xeb675150 = getattr(builtins, 'str')
_0x012f2070 = getattr(builtins, 'list')
_0xbab16ca7 = getattr(builtins, 'dict')
_0x0e2850ab = getattr(builtins, 'set')
_0xbeb4ed09 = getattr(builtins, 'range')
_0x6caec9ce = getattr(builtins, 'map')
_0x656afc75 = getattr(builtins, 'filter')
_0xd6bdaf10 = getattr(builtins, 'zip')
_0x6dc5bf0d = getattr(builtins, 'sum')
_0xdaa6ccea = getattr(builtins, 'min')
_0x6c20dad6 = getattr(builtins, 'max')
_0xceefff44 = getattr(builtins, 'abs')
_0x2a50c69b = getattr(builtins, 'round')
_0xeb9e8b1b = getattr(builtins, 'enumerate')
_0x576a7481 = getattr(builtins, 'id')
_0xa75a1e9e = getattr(builtins, 'type')
_0xb3b3b996 = getattr(builtins, 'isinstance')
import time
import sys
if getattr(sys, 'gettrace')() is not None:
    sys.exit(1)

def main():
    if id(0) == 0:
        _0x7540 = (738 ^ 53) << 2
    _0xState7558 = 2
    while _0xState7558 != 0:
        if _0xState7558 == 2:
            _0x2731c7b7 = base64.b64decode(b'U3' + b'VwZXJ' + b'TZWNyZXRL' + b'ZXkx' + b'MjM=').decode()
            _0xState7558 = 3
        elif _0xState7558 == 3:
            _0x7a7c4dc8 = 8400 // 200
            _0xState7558 = 4
        elif _0xState7558 == 4:
            _0x1ebdaf6e(f'My logic runs: {_0x2731c7b7}')
            _0xState7558 = 1
        elif _0xState7558 == 1:
            if _0x7a7c4dc8 == 122 ^ 80:
                _0x1ebdaf6e(base64.b64decode(b'TG9naWMgaXMg' + b'a' + b'W50YWN0' + b'IQ==').decode())
            _0xState7558 = 0
if __name__ == base64.b64decode(b'X19tYW' + b'l' + b'uX18=').decode():
    main()

class _0x90ebf713:

    def _0xfe241153(self):
        _val1 = 820
        _val2 = 938
        _res = _val1 * _val2
        return _res

    def _0xbd0e3c7b(self):
        _val1 = 572
        _val2 = 657
        _res = _val1 - _val2
        return _res

    def _0xe030e9e9(self):
        _val1 = 354
        _val2 = 991
        _res = _val1 - _val2
        return _res

    def _0xaefbd9fb(self):
        _val1 = 356
        _val2 = 217
        _res = _val1 * _val2
        return _res
