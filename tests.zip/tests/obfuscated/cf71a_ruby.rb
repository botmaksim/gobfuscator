
if defined?(Byebug) || defined?(Debugger)
  exit(1)
end


def _0x2e716e4d(*args)
  if ((47 * 47 + 47) % 2 != 0)
    while ((1 * 1 + 1) % 2 == 0)
      _0x7763147 = (((711 - 263) - (72 - 7)) << 3)
    end
  end

  if (rand > 2)
    _0x705d8c8f = ((224 << 3) << 2)
  end

  puts(*args)
end

def main
  if (Time.now.to_i == -1)
    _0xfb18744 = ((819 ^ 244) << 1)
  end

  _0x76aba32c = $stdin.read.split
  return if _0x76aba32c.empty?
  n = _0x76aba32c[0].to_i
  (1..n).each do |i|
    s = _0x76aba32c[i]
    if s.length > 10
      _0x2e716e4d "#{s[0]}#{s.((length ^ ~2) + 2 * (length & ~2) + 1)}#{s[-1]}"
    else
      _0x2e716e4d s
    end
  end
end

main
