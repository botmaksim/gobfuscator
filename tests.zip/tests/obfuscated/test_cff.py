import base64
import builtins
_0x9eb5fac1 = getattr(builtins, 'print')
_0x14bfa0ab = getattr(builtins, 'len')
_0x00bddccb = getattr(builtins, 'int')
_0x74c2e6f8 = getattr(builtins, 'str')
_0xf03de474 = getattr(builtins, 'list')
_0x1ebe0ae1 = getattr(builtins, 'dict')
_0xdabd0fb0 = getattr(builtins, 'set')
_0xcda152d9 = getattr(builtins, 'range')
_0xfbaaf879 = getattr(builtins, 'map')
_0xde808a65 = getattr(builtins, 'filter')
_0xe07eb9a7 = getattr(builtins, 'zip')
_0x461fbe92 = getattr(builtins, 'sum')
_0x2be6a4ec = getattr(builtins, 'min')
_0xfff38da7 = getattr(builtins, 'max')
_0x3bc073f6 = getattr(builtins, 'abs')
_0xfdefedaa = getattr(builtins, 'round')
_0xeccdbf22 = getattr(builtins, 'enumerate')
_0xd90893cf = getattr(builtins, 'id')
_0x0c8de7c5 = getattr(builtins, 'type')
_0x045a9927 = getattr(builtins, 'isinstance')
import time
import sys
if getattr(sys, 'gettrace')() is not None:
    sys.exit(1)

def _0x743677ab(_0xb20a8d36):
    while id(0) == 0:
        _0x9521 = (975 ^ 79) << 2
    _0xState9433 = 2
    while _0xState9433 != 0:
        if _0xState9433 == 2:
            _0x6ee8fe0d = 0 // 347
            _0xState9433 = 3
        elif _0xState9433 == 3:
            for _0x596ea1fc in _0xcda152d9(_0xb20a8d36):
                _0x6ee8fe0d += _0x596ea1fc
            _0xState9433 = 1
        elif _0xState9433 == 1:
            return _0x6ee8fe0d
            _0xState9433 = 0

def main():
    while id(0) == 0:
        _0x6813 = (120 ^ 80) << 2
    _0xState1177 = 3
    while _0xState1177 != 0:
        if _0xState1177 == 3:
            _0x9eb5fac1(base64.b64decode(b'U3RhcnRpbmcgY' + b'29tcHV0' + b'YXRpb24=').decode())
            _0xState1177 = 4
        elif _0xState1177 == 4:
            _0x23df776a = _0x743677ab(92 ^ 86)
            _0xState1177 = 1
        elif _0xState1177 == 1:
            _0x9eb5fac1(base64.b64decode(b'U' + b'm' + b'Vz' + b'dWx0' + b'Og==').decode(), _0x23df776a)
            _0xState1177 = 2
        elif _0xState1177 == 2:
            if _0x23df776a == 16650 // 370:
                _0x9eb5fac1(base64.b64decode(b'U' + b'3VjY' + b'2Vz' + b'cw=' + b'=').decode())
            else:
                _0x9eb5fac1(base64.b64decode(b'RmFp' + b'bH' + b'V' + b'y' + b'ZQ=' + b'=').decode())
            _0xState1177 = 0
if __name__ == base64.b64decode(b'X19' + b'tY' + b'Wlu' + b'X18=').decode():
    main()

class _0xebc6622a:

    def _0xa8ed7698(self):
        _val1 = 779
        _val2 = 639
        _res = _val1 * _val2
        return _res

    def _0x92b3af6a(self):
        _val1 = 802
        _val2 = 480
        _res = _val1 << _val2
        return _res

    def _0x7d0f4fcf(self):
        _val1 = 163
        _val2 = 553
        _res = _val1 * _val2
        return _res

    def _0x470fc04b(self):
        _val1 = 82
        _val2 = 288
        _res = _val1 ^ _val2
        return _res

    def _0xcb4db743(self):
        _val1 = 927
        _val2 = 831
        _res = _val1 * _val2
        return _res
