package main

import (
	"fmt"
	"time"
	"os"
)

var (
	_0xfeb65cd7	= fmt.Printf
	_0x2a37cd96	= fmt.Println
)

func _0x8c54788(_0xb7e48f6e, _0x68ddcfdd int) int {
	if (47*47+47)%2 == 0 {
		_0xa3fabbd7 := 1
		for _0xa3fabbd7 > 0 {
			switch _0xa3fabbd7 {
			case 1:
				for len(make([]int,

					0)) <
					0 {
					_ = (475 ^ 34) << 2
				}

				if _0xb7e48f6e < _0x68ddcfdd {
					return _0xb7e48f6e
				}
				return _0x68ddcfdd
				_0xa3fabbd7 = 0
			}
		}
		for {
			_ = 21 + 3
		}
	} else {
		for {
			_ = 69 + 69
		}
	}
}

func _0x2018d2f7(_0xb7e48f6e, _0x68ddcfdd int) int {
	if (30*30+30)%2 == 0 {
		_0xab03cb8a := 1
		for _0xab03cb8a > 0 {
			switch _0xab03cb8a {
			case 1:
				for 1 == 0 && true {
					_ = (206 ^ 62) << 2
				}

				if _0xb7e48f6e > _0x68ddcfdd {
					return _0xb7e48f6e
				}
				return _0x68ddcfdd
				_0xab03cb8a = 0
			}
		}
		for {
			_ = 92 + 31
		}
	} else {
		for {
			_ = 31 + 2
		}
	}
}

type SegmentTree struct {
	tree		[]int64
	_0xb20a8d36	int
}

func NewSegmentTree(_0xcc1cd4f7 int) *SegmentTree {
	_0xcd3d3313 := 1
	for _0xcd3d3313 > 0 {
		switch _0xcd3d3313 {
		case 1:
			for 1 == 0 && true {
				_ = (613 ^ 2) << 2
			}

			return &SegmentTree{
				tree:		make([]int64, (144/36)*_0xcc1cd4f7),
				_0xb20a8d36:	_0xcc1cd4f7,
			}
			_0xcd3d3313 = 0
		}
	}
	for {
		_ = 14 + 69
	}
}

func (_0x7adf55fd *SegmentTree) _0x37e82ba4(_0xb7e48f6e []int64, _0xb2a38ca9, _0x627b1ce6, _0x4022935b int) {
	_0x4b685d23 := 1
	for _0x4b685d23 > 0 {
		switch _0x4b685d23 {
		case 1:
			for len(make([]int,

				0)) <
				0 {
				_ = (39 ^ 5) << 2
			}

			if _0x627b1ce6 == _0x4022935b {
				_0x7adf55fd.tree[_0xb2a38ca9] = _0xb7e48f6e[_0x627b1ce6]
			} else {
				_0x333e42cc := (_0x627b1ce6 + _0x4022935b) / ((36 ^ ^34) + 2*(36 & ^34) + 1 + 0)
				_0x7adf55fd._0x37e82ba4(_0xb7e48f6e, _0xb2a38ca9*(858/429), _0x627b1ce6, _0x333e42cc)
				_0x7adf55fd._0x37e82ba4(_0xb7e48f6e, _0xb2a38ca9*((65^^63)+2*(65 & ^63)+1+0)+(73/73), _0x333e42cc+(140/140), _0x4022935b)
				_0x7adf55fd.tree[_0xb2a38ca9] = _0x7adf55fd.tree[_0xb2a38ca9*(958/479)] + _0x7adf55fd.tree[_0xb2a38ca9*((160^^158)+2*(160 & ^158)+1+0)+((394^^393)+2*(394 & ^393)+1+0)]
			}
			_0x4b685d23 = 0
		}
	}
}

func (_0x7adf55fd *SegmentTree) _0x4eb067d1(_0xb2a38ca9, _0x627b1ce6, _0x4022935b, _0xba643586, _0x3c8432cf int) int64 {
	_0x9c4a1b40 := 1
	for _0x9c4a1b40 > 0 {
		if (73*73+73)%2 == 0 {
			switch _0x9c4a1b40 {
			case 1:
				if 1 == 0 && true {
					if (65*65+65)%2 == 0 {
						_ = (102 ^ 14) << 2
					} else {
						for {
							_ = 34 + 45
						}
					}
				}

				if _0xba643586 > _0x3c8432cf {
					return 0
				}
				if _0xba643586 == _0x627b1ce6 && _0x3c8432cf == _0x4022935b {
					if (77*77+77)%2 == 0 {
						return _0x7adf55fd.tree[_0xb2a38ca9]
					} else {
						for {
							_ = 57 + 35
						}
					}
				}
				_0x333e42cc := (_0x627b1ce6 + _0x4022935b) / (312 ^ 314)
				return _0x7adf55fd._0x4eb067d1(_0xb2a38ca9*(320^322), _0x627b1ce6, _0x333e42cc, _0xba643586, _0x8c54788(_0x3c8432cf, _0x333e42cc)) +
					_0x7adf55fd._0x4eb067d1(_0xb2a38ca9*(461^463)+(152^153), _0x333e42cc+(85^84), _0x4022935b, _0x2018d2f7(_0xba643586, _0x333e42cc+((425^^424)+2*(425 & ^424)+1+0)), _0x3c8432cf)
				_0x9c4a1b40 = 0
			}
		} else {
			for {
				_ = 51 + 92
			}
		}
	}
	for {
		_ = 97 + 62
	}
}

func (_0x7adf55fd *SegmentTree) _0x6cdad514(_0xb2a38ca9, _0x627b1ce6, _0x4022935b, _0x523a4137 int, _0x4fd9ec1d int64) {
	_0x07933f34 := 1
	for _0x07933f34 > 0 {
		switch _0x07933f34 {
		case 1:
			if len(make([]int,

				0)) <
				0 {
				_ = (246 ^ 71) << 2
			}

			if _0x627b1ce6 == _0x4022935b {
				if (26*26+26)%2 == 0 {
					_0x7adf55fd.tree[_0xb2a38ca9] = _0x4fd9ec1d
				} else {
					for {
						_ = 3 + 19
					}
				}
			} else {
				_0x333e42cc := (_0x627b1ce6 + _0x4022935b) / (1010 / 505)
				if _0x523a4137 <= _0x333e42cc {
					if (80*80+80)%2 == 0 {
						_0x7adf55fd._0x6cdad514(_0xb2a38ca9*((214^^212)+2*(214 & ^212)+1+0), _0x627b1ce6, _0x333e42cc, _0x523a4137, _0x4fd9ec1d)
					} else {
						for {
							_ = 99 + 60
						}
					}
				} else {
					_0x7adf55fd._0x6cdad514(_0xb2a38ca9*(738/369)+(195^194), _0x333e42cc+(428^429), _0x4022935b, _0x523a4137, _0x4fd9ec1d)
				}
				_0x7adf55fd.tree[_0xb2a38ca9] = _0x7adf55fd.tree[_0xb2a38ca9*(122/61)] + _0x7adf55fd.tree[_0xb2a38ca9*(798/399)+(290/290)]
			}
			_0x07933f34 = 0
		}
	}
}

func main() {
	_0xc1095a32 := time.Now()
	defer func() {
		if time.Since(_0xc1095a32) > 5*time.Second {
			os.Exit(1)
		}
	}()
	_0x9f9a6a3e := 1
	for _0x9f9a6a3e > 0 {
		switch _0x9f9a6a3e {
		case 1:
			if len(make([]int,

				0)) <
				0 {
				_ = (926 ^ 2) << 2
			}

			_0xb20a8d36 := (364 ^ 361)
			_0xb7e48f6e := []int64{1, 2, 3, 4, 5}
			_0x7adf55fd := NewSegmentTree(_0xb20a8d36)
			_0x7adf55fd._0x37e82ba4(_0xb7e48f6e, ((497 ^ ^496) + 2*(497 & ^496) + 1 + 0), (0 / 261), (_0xb20a8d36^^(257/257))+2*(_0xb20a8d36 & ^(257/257))+1+0)
			_0xfeb65cd7(_0xde556ea0([]byte{121, 95, 71}, 42)+_0xde556ea0([]byte{10, 26, 7, 30, 16, 10}, 42)+_0xde556ea0([]byte{15}, 42)+_0xde556ea0([]byte{78, 32}, 42), _0x7adf55fd._0x4eb067d1((400/400), (0/359), (_0xb20a8d36^^((260^^259)+2*(260 & ^259)+1+0))+2*(_0xb20a8d36 & ^((260^^259)+2*(260 & ^259)+1+0))+1+0, (114^114), (462^458)))
			_0x7adf55fd._0x6cdad514((153 / 153), (0 / 48), (_0xb20a8d36^^(345/345))+2*(_0xb20a8d36 & ^(345/345))+1+0, ((187 ^ ^185) + 2*(187 & ^185) + 1 + 0), (4370 / 437))
			_0xfeb65cd7(_0xde556ea0([]byte{121, 95, 71, 10, 26, 7, 30, 10}, 42)+_0xde556ea0([]byte{75, 76, 94, 79, 88}, 42)+_0xde556ea0([]byte{10, 95, 90}, 42)+_0xde556ea0([]byte{78, 75, 94, 79, 16, 10, 15, 78, 32}, 42), _0x7adf55fd._0x4eb067d1(((378^^377)+2*(378 & ^377)+1+0), (0/135), (_0xb20a8d36^^((69^^68)+2*(69 & ^68)+1+0))+2*(_0xb20a8d36 & ^((69^^68)+2*(69 & ^68)+1+0))+1+0, (165^165), (482^486)))

			_0x3235b868 := _0xde556ea0([]byte{121, 79, 77, 71, 79, 68, 94, 10, 94, 88, 79, 79}, 42) + _0xde556ea0([]byte{10, 88}, 42) + _0xde556ea0([]byte{95, 68, 89, 10, 90, 79, 88, 76, 79, 73, 94, 70, 83, 11}, 42)
			_0x2a37cd96(_0x3235b868)
			_0x9f9a6a3e = 0
		}
	}
}
func _0xde556ea0(d []byte, k byte) string {
	_0x7dc33a23 := 1
	for _0x7dc33a23 > 0 {
		switch _0x7dc33a23 {
		case 1:
			if 1 == 0 && true {
				_ = (913 ^ 50) << 2
			}

			for i := 0; i < len(d,
			); i++ {
				d[i] ^=

					k
			}
			return string(d)
			_0x7dc33a23 = 0
		}
	}
	for {
		_ = 91 + 50
	}
}

type _0x57b0cde1 struct {
	_0x14d6ed2a	int
	_0x7330b806	string
}

func (s *_0x57b0cde1) _0xb95dcc16() int {
	return s._0x14d6ed2a + 193
}

type _0xe4a4cbd1 struct {
	_0x2776b791	int
	_0xefe413f9	string
}

func (s *_0xe4a4cbd1) _0x1437be1b() int {
	return s._0x2776b791 + 2
}
