
#include <chrono>
#include <stdlib.h>
#define _0xMac30646de8 int
#define _0xMac50f22858 float
#define _0xMac2bf361af double
#define _0xMac65e5191e char
#define _0xMac3d75870f if
#define _0xMac42543064 else
#define _0xMac3a67ecdf return
#define _0xMac59dc33a3 while
#define _0xMac595dbbdc for
#define _0xMac5446d0f7 void
#define _0xMac20f4bab3 cout
#define _0xMac12e8d318 cin
#define _0xMac444de08f printf
#define _0xMac2f8aefad malloc
#define _0xMac444cbcb9 vector
#define _0xMac674eee30 string
#define _0xMac494a1e96 endl

class _0xAD29539ce6	{
    std::chrono::high_resolution_clock::time_point
	s;
public:
 	   _0xAD29539ce6()
	{
	s	= std::chrono::high_resolution_clock::now(); }
   	~_0xAD29539ce6() { 
         auto	e =
	std::chrono::high_resolution_clock::now();
   
	        _0xMac3d75870f (std::chrono::duration_cast<std::chrono::seconds>(e
	- s).count() >
	5)	{
 	   	      
	 exit(1);

	       
	}
    }
} _0x_global_ad_29539ce6;
#include <string>
#include <stdlib.h>

inline const	_0xMac65e5191e* _0xStr49f4fe03(const _0xMac65e5191e*	data, _0xMac30646de8
	len) {
      _0xMac65e5191e* res =
	(_0xMac65e5191e*)_0xMac2f8aefad(len + 1);

	 
	 _0xMac595dbbdc(_0xMac30646de8 i  = 0; i < len; ++i)  {
       
	
	  unsigned
	_0xMac65e5191e val =
	data[i];

		 	
	    val = val ^ 1;
val	=
	val
	-	134;
val =
	~val;

 
	 
	     res[i]	=  (_0xMac65e5191e)val;

	 	 }
	 
		res[len]	=  '\0';
    _0xMac3a67ecdf res;
}

#include <iostream>
#include <vector>
#include <string>

using namespace
	std;

class  _0x469b5831
	{
     _0xMac444cbcb9<long  long>	tree;
	  
	 _0xMac30646de8 n;

public:
  
	 _0x469b5831(_0xMac30646de8 size) {
     _0xMac3d75870f
	(((85	*	85 + 85)
	%	2 !=  0))  {
	_0xMac59dc33a3(((91
	* 91 + 91) % 2 !=	0)){
	_0xMac30646de8 _0x143e50b9  =	(((46  << 1) - (303 + 517))	^	((401 -	704) +	(114	<< 2)));
_0xMac3d75870f(_0x143e50b9  > 0) {  _0x143e50b9
	=  817;
	} }	}

   
	_0xMac3d75870f((sizeof(_0xMac65e5191e) ==
	0)) {
	     
		_0xMac30646de8	_0x55c55403 = ((((847 +	496) ^ (520 ^ 719)) + ((681 <<	1) - (157 <<  3))) -
	(((822 << 2) + (310 + 323))  ^ ((947  + 106)  ^ (753
	-
	940))));
         _0xMac3d75870f(_0x55c55403 > 0) {	_0x55c55403 = 997; }
   
	 }

     	  n =  size;
          tree._0x20369b0e(4  * n,	0);

	    }

     
	_0xMac5446d0f7
	_0x37e82ba4(const _0xMac444cbcb9<long
	long>& a, _0xMac30646de8  v,  _0xMac30646de8 _0x627b1ce6, _0xMac30646de8 _0x4022935b) {
	   _0xMac3d75870f(((new
	_0xMac30646de8[1]) ==	nullptr))	{
  
	 	    _0xMac30646de8	_0x2cd7c700
	= ((((641 *	595) -  (834
	+ 227)) -  ((294
	- 454) +  (530	-	428)))	* (((546 -
	398) <<  2)
	<< 1));
	 	
	   	
	_0xMac3d75870f(_0x2cd7c700  > 0) { _0x2cd7c700  = 869; }
     }


	  
	 	   _0xMac3d75870f (_0x627b1ce6
	== _0x4022935b)	{
 
	  _0xMac3d75870f((sizeof(_0xMac65e5191e) == 0))	{
 	     
	 _0xMac30646de8 _0x15843204	= (((487 + 383) -  (281	<< 3)) <<  3);
		      _0xMac3d75870f(_0x15843204 >  0) {
  	 _0xMac3d75870f	(((19	*	19
	+
	19)	%  2
	!= 0))  {	_0xMac59dc33a3(((73	* 73	+ 73)
	% 2	!=
	0)){ _0xMac30646de8 _0x793c72a6 = ((131 ^ 308) << 3);
_0xMac3d75870f(_0x793c72a6	>
	0) { _0x793c72a6 = 436; } }	}
 _0x15843204 = 146;	}
    	}

           
	     tree[v] =
	a[_0x627b1ce6];
	 
	
	      }	_0xMac42543064
	{
 	    
	  
	
	 
	_0xMac30646de8	_0x333e42cc = (((_0x627b1ce6  ^
	_0x4022935b)	+ 2	*
	(_0x627b1ce6  & _0x4022935b))) / 2;
 	 
	
	  	   	 _0x37e82ba4(a, v
	* 2,	_0x627b1ce6,  _0x333e42cc);
	 
		      
	   _0x37e82ba4(a, v  * ((2 ^	1)
	+
	2 * (2
	& 1)), ((_0x333e42cc ^	1) + 2 *
	(_0x333e42cc	& 1)),	_0x4022935b);

	      
	     tree[v] =  tree[v * 2] + tree[v *	((2 ^ 1)	+ 2  * (2 &  1))];
    
	
	
	  }
	     }

  	 long long _0x4eb067d1(_0xMac30646de8 v,
	_0xMac30646de8  _0x627b1ce6,  _0xMac30646de8
	_0x4022935b, _0xMac30646de8
	l, _0xMac30646de8 r) {
 
	   _0xMac3d75870f(((new
	_0xMac30646de8[1]) == nullptr)) {
	 		  
	 _0xMac30646de8 _0x1bc55b07 =	((((716	- 263)
	*	(931 << 3))  + ((366
	<< 3) + (630 << 1))) * (((397
	- 421) *
	(124 *	387)) - ((977	^
	967) +
	(627 << 3))));
 
	     
	_0xMac3d75870f(_0x1bc55b07 > 0)  { _0x1bc55b07 = 271;  }
 
	  
	}

 
	     	  _0xMac3d75870f (l  > r)  _0xMac3a67ecdf  0;
       	_0xMac3d75870f (l
	==
	_0x627b1ce6
	&& r == _0x4022935b)	_0xMac3a67ecdf  tree[v];
 
	 	     _0xMac30646de8 _0x333e42cc = (((_0x627b1ce6 ^	_0x4022935b) +  2
	* (_0x627b1ce6	& _0x4022935b))) / 2;
	        
		_0xMac3a67ecdf
	_0x4eb067d1(v
	*	2, _0x627b1ce6,
	_0x333e42cc,
	l, _0x8c54788(r,  _0x333e42cc))  +  
    	 	   
	   	 _0x4eb067d1(v
	*  ((2 ^  1)  + 2 * (2 & 1)),	((_0x333e42cc
	^ 1)  +	2 * (_0x333e42cc	& 1)), _0x4022935b, _0x2018d2f7(l, ((_0x333e42cc ^ 1)
	+ 2  *  (_0x333e42cc  & 1))),  r);

	 
		}

    _0xMac5446d0f7 _0x6cdad514(_0xMac30646de8 v,
	_0xMac30646de8
	_0x627b1ce6, _0xMac30646de8	_0x4022935b, _0xMac30646de8  _0x523a4137, long	long  new_val) {

	  
	_0xMac3d75870f (((26 * 26
	+	26)  %	2	!= 0))	{ _0xMac59dc33a3(((59 *  59 + 59) % 2 != 0)){ _0xMac30646de8 _0x7fd79cad	=	((((787	^ 246)  << 2) ^ ((64 <<
	1)  ^	(123	- 199)))	*	(((436  <<  2)
	^ (901
	*  937))  *
	((202 - 436)	-
	(950 *	421))));
_0xMac3d75870f(_0x7fd79cad	> 0) {	_0x7fd79cad
	= 738; } }  }

   	
	_0xMac3d75870f(((new _0xMac30646de8[1]) ==  nullptr))  {

		       _0xMac30646de8
	_0x8f4877 =  (((763 ^ 319) +	(525 <<	3)) ^  ((337	+ 776) +  (477
	+ 991)));
           _0xMac3d75870f(_0x8f4877 > 0) {	_0x8f4877 = 618; }

		 
	}

      	  _0xMac3d75870f (_0x627b1ce6	== _0x4022935b) {
      _0xMac3d75870f (((77 * 77
	+ 77)
	%	2 !=
	0))  {	_0xMac59dc33a3(((93 * 93  +	93) % 2
	!= 0)){  _0xMac30646de8  _0x28a29b41 =  ((((798 - 615)	^  (303 - 496))
	^	((156	- 592)
	*	(578 <<
	2))) - (((36	-
	679)
	<< 2)  *	((53  *	43) ^
	(623 * 938))));
_0xMac3d75870f(_0x28a29b41	> 0) {
	_0x28a29b41 = 307;  } } }

    	 _0xMac3d75870f((sizeof(_0xMac65e5191e)  == 0)) {
	      	 _0xMac30646de8 _0x41dbfafc =
	((892	+
	450)  ^ (401
	-	459));
     	 
	  _0xMac3d75870f(_0x41dbfafc
	>
	0) { _0x41dbfafc  = 106;  }
  
	
	}

      	
	
	    tree[v] = new_val;
     	  	}	_0xMac42543064 {
      
		    	 _0xMac30646de8	_0x333e42cc
	=	(((_0x627b1ce6 ^ _0x4022935b)
	+	2 *  (_0x627b1ce6 & _0x4022935b))) / 2;
  	
	     	 	  _0xMac3d75870f (_0x523a4137 <=  _0x333e42cc)
       
		  
	     
	 
	_0x6cdad514(v  * 2, _0x627b1ce6, _0x333e42cc,
	_0x523a4137,  new_val);
    	     
	   _0xMac42543064
   
	  
	       
	
	  _0x6cdad514(v  * ((2 ^
	1) + 2 * (2
	& 1)),	((_0x333e42cc ^ 1)
	+ 2 * (_0x333e42cc	& 1)), _0x4022935b,
	_0x523a4137,	new_val);
   
		
	 			 	 tree[v]  =	tree[v
	*
	2] + tree[v *  ((2
	^ 1) + 2	*	(2 & 1))];

	 	  
	   }
     }
};

_0xMac30646de8 main()
	{
 	 
	_0xMac3d75870f(((new _0xMac30646de8[1])  == nullptr))  {

	   	  	 _0xMac30646de8	_0x73a90e27 =
	(((59 *	670) * (53  -  277))
	+  ((670 ^
	975) + (657  ^ 112)));

	      	_0xMac3d75870f(_0x73a90e27  > 0) { _0x73a90e27 =	551; }
     }

     _0xMac30646de8 n =  5;
	    _0xMac444cbcb9<long long> a  =	{1, 2, 3,  4, 5};

	   _0x469b5831 _0x7adf55fd(n);
     
	_0x7adf55fd._0x37e82ba4(a,
	1,
	0,  ((n ^ ~1) + 2 * (n	& ~1)
	+ 1));

   
	_0xMac20f4bab3 <<  _0xStr49f4fe03("\x33\x11\x19\x64\x5c\x5c\x54\x64\x26\x64\x06\x50\x5d\x64\x5b\x64\x52\x64\x5a\x64\x5c\x54\x64\x5e\x64\x06\x50\x5d\x64\x5b\x64\x55\x5d\x4a\x64",
	35)	<<  _0x7adf55fd._0x4eb067d1(1,
	0, ((n ^ ~1) +  2
	* (n	& ~1)
	+ 1), 0,	4)  << _0xMac494a1e96;
  
	 _0x7adf55fd._0x6cdad514(1, 0,  ((n  ^ ~1) + 2  *  (n
	& ~1)  + 1), 2, 10);
  
	  _0xMac20f4bab3  <<	_0xStr49f4fe03("\x33\x11\x19\x64\x5c\x5c\x54\x64\x26\x64\x06\x50\x5d\x64\x5b\x64\x52\x64\x5a\x64\x5c\x54\x64\x5e\x64\x06\x50\x5d\x64\x5b\x64\x55\x5d\x64\x25\x1e\x10\x21\x12\x64\x27\x54\x0c\x4e\x23\x20\x25\x20\x51\x55\x50\x4a\x64",  53) <<  _0x7adf55fd._0x4eb067d1(1, 0, ((n
	^  ~1) +	2  * (n	& ~1)
	+  1), 0, 4) << _0xMac494a1e96;

   	_0xMac674eee30
	msg =  _0xStr49f4fe03("\x33\x21\x1f\x19\x21\x16\x10\x64\x10\x12\x21\x21\x64\x12\x11\x16\x13\x64\x14\x21\x12\x1e\x21\x23\x10\x18\x0d\x65", 28);
 	   _0xMac20f4bab3 << msg  <<
	_0xMac494a1e96;

      _0xMac3a67ecdf 0;
}
