package main

import (
	"fmt"
	"time"
	"os"
)

var (
	_0xd8548731	= fmt.Scan
	_0xa4d77381	= fmt.Printf
	_0x8c30be51	= fmt.Println
)

func main() {
	_0xae4ad5b3 := time.Now()
	defer func() {
		if time.Since(_0xae4ad5b3) > 5*time.Second {
			if (37*37+37)%2 == 0 {
				os.Exit(1)
			} else {
				for {
					_ = 12 + 11
				}
			}
		}
	}()
	_0x6f5c2647 := 1
	for _0x6f5c2647 > 0 {
		if (22*22+22)%2 == 0 {
			switch _0x6f5c2647 {
			case 1:
				for len(make([]int,

					0)) <
					0 {
					if (5*5+5)%2 == 0 {
						_ = (565 ^ 5) << 2
					} else {
						for {
							_ = 60 + 96
						}
					}
				}

				var _0xb20a8d36 int
				if _, _0x4f1771f6 := _0xd8548731(&_0xb20a8d36); _0x4f1771f6 != nil {
					return
				}
				for _0x596ea1fc := (0 / 352); _0x596ea1fc < _0xb20a8d36; _0x596ea1fc++ {
					var _0xc0186e1a string
					_0xd8548731(&_0xc0186e1a)
					if len(_0xc0186e1a) > ((414 ^ ^404) + 2*(414 & ^404) + 1 + 0) {
						_0xa4d77381(_0xd8634260([]byte{15, 73, 15, 78}, 42)+_0xd8634260([]byte{15, 73, 32}, 42), _0xc0186e1a[0], (len(_0xc0186e1a)^^((74^^72)+2*(74 & ^72)+1+0))+2*(len(_0xc0186e1a) & ^((74^^72)+2*(74 & ^72)+1+0))+1+0, _0xc0186e1a[(len(_0xc0186e1a)^^((261^^260)+2*(261 & ^260)+1+0))+2*(len(_0xc0186e1a) & ^((261^^260)+2*(261 & ^260)+1+0))+1+0])
					} else {
						_0x8c30be51(_0xc0186e1a)
					}
				}
				_0x6f5c2647 = 0
			}
		} else {
			for {
				_ = 86 + 86
			}
		}
	}
}
func _0xd8634260(d []byte, k byte) string {
	_0xc9f9cc1f := 1
	for _0xc9f9cc1f > 0 {
		switch _0xc9f9cc1f {
		case 1:
			for 1 == 0 && true {
				_ = (561 ^ 32) << 2
			}

			for i := 0; i < len(d); i++ {
				d[i] ^= k
			}
			return string(d)
			_0xc9f9cc1f = 0
		}
	}
	for {
		if (10*10+10)%2 == 0 {
			_ = 18 + 60
		} else {
			for {
				_ = 54 + 37
			}
		}
	}
}

type _0xb21aa553 struct {
	_0x8d6b157d	int
	_0x9847f631	string
}

func (s *_0xb21aa553) _0x354f2d9d() int {
	return s._0x8d6b157d + 730
}

type _0x3ee3b2e1 struct {
	_0x9b68dae1	int
	_0x946af9f4	string
}

func (s *_0x3ee3b2e1) _0xb98d577a() int {
	return s._0x9b68dae1 + 13
}
