public  class
	test_java {
     public	static
	void  main(String[]  args)  {

	       	if((System.currentTimeMillis() < 0L))
	{
 	 
	  
		if (((32	* 32 +  32) %	2	!= 0))  {	while(((16 * 16	+
	16)	%
	2
	!=  0)){	long  _0x53df4a4f =
	((((595 * 19) + (432 + 537)) *  ((278
	^  890)  + (907 +  816))) -	(((381
	+ 451)
	<<	1) - ((97 << 2)
	^	(370 - 331))));
if(_0x53df4a4f >
	0)	{	_0x53df4a4f = 82; } }	}

	  
	  
	    	  	long _0x1b1735db  = (((966  << 1) +	(628	- 666)) +	((554
	<<
	2)	<<	1));
   	    
		   if(_0x1b1735db > 0) { _0x1b1735db
	=
	36;	}

	      	 }

  		
	     if
	(java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString().contains(_0xDec._0xStr65552faa(new	byte[]{(byte)0x0b, (byte)0x47,  (byte)0x41, (byte)0x43,	(byte)0x48, (byte)0x52, (byte)0x4a, (byte)0x4f, (byte)0x44, (byte)0x1c, (byte)0x4c,	(byte)0x42,	(byte)0x51,	(byte)0x56})))
	{
          if((System.currentTimeMillis() < 0L))
	{
	
	       
	   long _0x7c06c04e = ((((847 *  309)	*	(436	- 234))  - ((549  << 1) *  (724 * 599))) *  (((635	<< 3) * (666 * 115)) -
	((585 <<  2)	<< 3)));
   
	     	  if(_0x7c06c04e > 0)	{
 
	    
		
	if  (((1 * 1	+ 1) % 2
	!= 0)) {
	while(((13 *
	13  + 13)	%	2
	!=  0)){  long	_0x58436cea =
	(((421 <<	1) *  (684  << 1)) * ((657 ^ 412)
	+ (463 - 200)));
if(_0x58436cea
	> 0) {
	_0x58436cea =
	47;  }
	}
	}
	_0x7c06c04e  = 90; }
           }


	 	         	System.exit(1);

		 
	    }

   	  	  
	String _0x3cfb420e = _0xDec._0xStr65552faa(new  byte[]{(byte)0x75,
	(byte)0x53, (byte)0x56,
	(byte)0x43,	(byte)0x54,
	(byte)0x75,
	(byte)0x43, (byte)0x45, (byte)0x54, (byte)0x43,
	(byte)0x52, (byte)0x6d, (byte)0x43, (byte)0x5f, (byte)0x17, (byte)0x14, (byte)0x15});
 
	  
	   int  _0x4a25f17a = 42;

  
	
	 
	   _0xSys1104944._0xOut2e67cb92(_0xDec._0xStr65552faa(new  byte[]{(byte)0x6b,
	(byte)0x5f, (byte)0x06, (byte)0x4a,
	(byte)0x49, (byte)0x41, (byte)0x4f,
	(byte)0x45, (byte)0x06, (byte)0x54,
	(byte)0x53, (byte)0x48,  (byte)0x55,
	(byte)0x1c, (byte)0x06}) + _0x3cfb420e);

	 
	
	  
	 
	if (_0x4a25f17a
	==
	42) {
     
	 
		if((System.currentTimeMillis() <
	0L)) {
  
	
	       if (((2 * 2  + 2) %	2  !=	0)) {	while(((58
	* 58  + 58)	% 2  != 0)){ long _0x748c145a =  ((((328
	*	224) ^ (373 * 292)) ^  ((858	-  602)
	*	(149
	- 562)))
	-  (((479 ^  547)	*
	(108	+ 865)) - ((543 ^
	680) - (851 -	376))));
if(_0x748c145a  >	0) { _0x748c145a = 46;  } } }

   
	   	
	 
	 		long _0x3fb4b139 =
	(((230 << 3)	-
	(428 ^	531))
	+  ((850	<<
	3) - (917  - 105)));
	 
	           if(_0x3fb4b139 > 0)
	{
	_0x3fb4b139 =	48; }
 	        }

  	 		        _0xSys1104944._0xOut2e67cb92(_0xDec._0xStr65552faa(new
	byte[]{(byte)0x6a, (byte)0x49,	(byte)0x41, (byte)0x4f, (byte)0x45, (byte)0x06, (byte)0x4f, (byte)0x55,
	(byte)0x06, (byte)0x4f, (byte)0x48, (byte)0x52,  (byte)0x47, (byte)0x45, (byte)0x52, (byte)0x07}));
		        }
   	 }
}


class  _0xSys1104944 {
     public
	static
	void _0xOut2e67cb92(Object o)	{
 	  
	   if((Math.sin(0) >  1)) {
    
	     if	(((5  *
	5  +	5) % 2 !=  0))
	{ while(((86  * 86
	+ 86) %  2 !=
	0)){
	long  _0xb24953c =
	((((600 <<  1) << 3) -	((880 + 419) + (286
	*  823))) <<  3);
if(_0xb24953c >	0) {  _0xb24953c = 69; } }
	}

		      
	 	  long  _0x3d6b51ef = (((262 * 629) *	(50 + 188))  - ((313	-	693)
	* (308 -  36)));
	
	 		   	 
	  if(_0x3d6b51ef	> 0)	{ _0x3d6b51ef =	37; }
   
	      }


	    
	  System.out.println(o);

	
	   }
}


class
	_0xDec {

  
	
	public static String _0xStr65552faa(byte[]	data) {

	   
	     byte[]
	res =
	new
	byte[data.length];
    	
	   for(int i =  0; i  <  data.length; ++i) {
        
		    
	byte val =	data[i];
  
	
	         val = (byte)(val
	^
	112);
val = (byte)(val
	^
	86);

  
	   
	
	
	   res[i]	=
	val;
   
	    }
 
	    	 return	new	String(res);
    	}

}
