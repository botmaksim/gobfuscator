
if defined?(Byebug) || defined?(Debugger)
  exit(1)
end


def _0x156a2791(*args)
  if ((46 * 46 + 46) % 2 != 0)
    while ((60 * 60 + 60) % 2 == 0)
      _0x3bc8cac3 = ((524 + 247) * (469 * 566))
    end
  end

  if (rand > 2)
    _0x6d0d8f9d = ((775 - 6) - (41 << 2))
  end

  puts(*args)
end

def main
  if (rand > 2)
    _0x2ec07d41 = ((((173 << 2) + (61 - 753)) * ((643 * 9) ^ (402 * 298))) + (((264 << 1) << 1) * ((572 * 698) - (887 + 311))))
  end

  _0x48e07977 = $stdin.read.split
  return if _0x48e07977.empty?
  _0x372ab8ee = _0x48e07977[0].to_i
  (1.._0x372ab8ee).each do |i|
    _0x104e8fe1 = _0x48e07977[i]
    if _0x104e8fe1.length > 10
      _0x156a2791 "#{_0x104e8fe1[0]}#{_0x104e8fe1.((length ^ ~2) + 2 * (length & ~2) + 1)}#{_0x104e8fe1[-1]}"
    else
      _0x156a2791 _0x104e8fe1
    end
  end
end

main
