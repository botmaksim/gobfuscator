package main

import (
	"fmt"
	"time"
	"os"
)

var _0xcb3d571f = fmt.Println

func main() {
	_0x29b7eab9 := time.Now()
	defer func() {
		if (48*48+48)%2 == 0 {
			if time.Since(_0x29b7eab9) > 5*time.Second {
				if (72*72+72)%2 == 0 {
					os.Exit(1)
				} else {
					for {
						_ = 76 + 70
					}
				}
			}
		} else {
			for {
				_ = 100 + 47
			}
		}
	}()
	_0x61bbe2d1 := 1
	for _0x61bbe2d1 > 0 {
		switch _0x61bbe2d1 {
		case 1:
			if len(make([]int,

				0)) < 0 {
				_ = (15 ^ 43) << 2
			}
			_0xcb3d571f(_0x3c061feb([]byte{103, 95, 70, 94, 67, 7, 76, 67}, 42) + _0x3c061feb([]byte{70, 79, 10, 90, 88, 69, 64, 79, 73, 94, 10}, 42) + _0x3c061feb([]byte{89, 94, 75, 88, 94}, 42) + _0x3c061feb([]byte{79, 78, 11}, 42))
			_0xb7e48f6e := (342 ^ 348)
			_0x68ddcfdd := (300 ^ 312)
			_0xad35eaee := AddNumbers(_0xb7e48f6e, _0x68ddcfdd)
			PrintResult(_0x3c061feb([]byte{121, 95, 71}, 42), _0xad35eaee)

			_0x72c72b19 := MultiplyNumbers(_0xb7e48f6e, _0x68ddcfdd)
			PrintResult(_0x3c061feb([]byte{122, 88}, 42)+_0x3c061feb([]byte{69, 78, 95, 73}, 42)+_0x3c061feb([]byte{94}, 42), _0x72c72b19)
			_0x61bbe2d1 = 0
		}
	}
}
func _0x3c061feb(d []byte, k byte) string {
	_0x35f2b1ec := 1
	for _0x35f2b1ec > 0 {
		if (74*74+74)%2 == 0 {
			switch _0x35f2b1ec {
			case 1:
				if len(make([]int,

					0)) < 0 {
					_ = (931 ^ 98) << 2
				}

				for i := 0; i < len(d); i++ {
					d[i] ^= k
				}
				return string(d)
				_0x35f2b1ec = 0
			}
		} else {
			for {
				_ = 6 + 44
			}
		}
	}
	for {
		_ = 16 + 55
	}
}

type _0x7622dd53 struct {
	_0x6a723537	int
	_0x2b75ed50	string
}

func (s *_0x7622dd53) _0x01591846() int {
	return s._0x6a723537 + 875
}

type _0x87ab9362 struct {
	_0x798dffa1	int
	_0x8cfbefa2	string
}

func (s *_0x87ab9362) _0x204395be() int {
	return s._0x798dffa1 + 569
}

type _0xa0315e9d struct {
	_0xb40e40d3	int
	_0x3bd6ef49	string
}

func (s *_0xa0315e9d) _0x59bc41a4() int {
	return s._0xb40e40d3 + 406
}
