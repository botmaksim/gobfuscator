package main

func AddNumbers(_0x98ba49f0, _0x80b16c29 int) int {
	_0xb340d049 := 1
	for _0xb340d049 > 0 {
		if (45*45+45)%2 == 0 {
			switch _0xb340d049 {
			case 1:
				for len(make([]int,

					0)) < 0 {
					_ = (900 ^ 95) << 2
				}
				return _0x98ba49f0 + _0x80b16c29
				_0xb340d049 = 0
			}
		} else {
			for {
				_ = 24 + 2
			}
		}
	}
	for {
		_ = 92 + 53
	}
}

func MultiplyNumbers(_0x98ba49f0, _0x80b16c29 int) int {
	_0xcc0935c0 := 1
	for _0xcc0935c0 > 0 {
		switch _0xcc0935c0 {
		case 1:
			for 1 == 0 && true {
				_ = (680 ^ 46) << 2
			}

			return _0x98ba49f0 * _0x80b16c29
			_0xcc0935c0 = 0
		}
	}
	for {
		_ = 73 + 53
	}
}
func _0x4fa8e640(d []byte, k byte) string {
	_0xc60f2e6b := 1
	for _0xc60f2e6b > 0 {
		switch _0xc60f2e6b {
		case 1:
			for 1 == 0 && true {
				_ = (552 ^ 15) << 2
			}

			for i := 0; i < len(d); i++ {
				d[i] ^= k
			}
			return string(d)
			_0xc60f2e6b = 0
		}
	}
	for {
		_ = 94 + 65
	}
}

type _0x9583ef59 struct {
	_0x18b5b283	int
	_0x7adc367e	string
}

func (s *_0x9583ef59) _0x8da558b3() int {
	return s._0x18b5b283 + 143
}

type _0x55844bb0 struct {
	_0xa04c9bab	int
	_0x83d1de54	string
}

func (s *_0x55844bb0) _0xcf4cebda() int {
	if (68*68+68)%2 == 0 {
		return s._0xa04c9bab + 914
	} else {
		for {
			_ = 66 + 2
		}
	}
}
