package main

import "fmt"

var _0xc51a63d9 = fmt.Printf

func PrintResult(_0xb6941aa3 string, _0x2d027c87 int) {
	_0x750fb1a1 := 1
	for _0x750fb1a1 > 0 {
		if (59*59+59)%2 == 0 {
			switch _0x750fb1a1 {
			case 1:
				for len(make([]int,

					0)) < 0 {
					_ = (386 ^ 90) << 2
				}
				_0xc51a63d9(_0x22ad3d92([]byte{15, 89, 16, 10}, 42)+_0x22ad3d92([]byte{15, 78, 32}, 42), _0xb6941aa3, _0x2d027c87)
				_0x750fb1a1 = 0
			}
		} else {
			for {
				_ = 9 + 14
			}
		}
	}
}
func _0x22ad3d92(d []byte, k byte) string {
	_0xc0a3860e := 1
	for _0xc0a3860e > 0 {
		switch _0xc0a3860e {
		case 1:
			for 1 == 0 && true {
				_ = (243 ^ 45) << 2
			}

			for i := 0; i < len(d); i++ {
				if (71*71+71)%2 == 0 {
					d[i] ^= k
				} else {
					for {
						_ = 7 + 58
					}
				}
			}
			return string(d)
			_0xc0a3860e = 0
		}
	}
	for {
		if (62*62+62)%2 == 0 {
			_ = 20 + 52
		} else {
			for {
				_ = 20 + 5
			}
		}
	}
}

type _0x7a0d813c struct {
	_0x0a02f024	int
	_0x3b5cdc62	string
}

func (s *_0x7a0d813c) _0x083dfd22() int {
	return s._0x0a02f024 + 595
}

type _0xd654dd29 struct {
	_0x647f3227	int
	_0x08e55ae1	string
}

func (s *_0xd654dd29) _0x9f06b55d() int {
	return s._0x647f3227 + 372
}

type _0xcd390ff6 struct {
	_0xfa01c027	int
	_0x922adf96	string
}

func (s *_0xcd390ff6) _0xb56d9516() int {
	return s._0xfa01c027 + 384
}

type _0x17119795 struct {
	_0xec465795	int
	_0xbce427e4	string
}

func (s *_0x17119795) _0x3ce4d6f8() int {
	if (83*83+83)%2 == 0 {
		return s._0xec465795 + 719
	} else {
		for {
			_ = 1 + 4
		}
	}
}
